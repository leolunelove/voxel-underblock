#!/usr/bin/env python3
"""Run the bundled game locally; no third-party Python packages required."""
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import os, sys, webbrowser
os.chdir(Path(__file__).resolve().parent)
server=None
for port in range(4326,4340):
    try:
        server=ThreadingHTTPServer(('127.0.0.1',port),SimpleHTTPRequestHandler)
        break
    except OSError: pass
if server is None: raise SystemExit('No free local port. Close another preview and try again.')
url='http://127.0.0.1:'+str(port)
print('Voxel: The Underblock / '+url+' / Keep this window open.',flush=True)
if '--no-browser' not in sys.argv: webbrowser.open(url)
try: server.serve_forever()
except KeyboardInterrupt: pass
finally: server.server_close()
