// A diagonal cut across the body: windup, edge contact, broad follow-through.
// The opposite stroke mirrors the arc, so holding attack creates a calm two-cut rhythm.
export function swordSlashPose(phase,aspect,motion=1,side=1){
 const keys=[[0,.36,-.48,-1.88,-.22,-.22,-.32],[.16,.53,-.26,-1.72,-.13,-.38,-1.05],[.30,.03,-.40,-2.02,-.72,.12,.24],[.43,-.49,-.59,-1.88,-.95,.36,1.12],[.56,-.52,-.51,-1.72,-.63,.27,1.02],[.84,-.36,-.48,-1.88,-.22,.22,.32],[1,-.36,-.48,-1.88,-.22,.22,.32]];
 const rest=keys[0].slice(1);let pose=rest;
 for(let i=1;i<keys.length;i++){const a=keys[i-1],b=keys[i];if(phase<=b[0]){let t=Math.max(0,(phase-a[0])/(b[0]-a[0]));t=i===2?t*t:t*t*(3-2*t);pose=a.slice(1).map((v,j)=>v+(b[j+1]-v)*t);break;}}
 const p=rest.map((v,i)=>v+(pose[i]-v)*motion),width=Math.tan(24*Math.PI/180)*1.9*Math.max(.45,aspect),narrow=Math.min(1,width/.76);
 // Keep the hilt within a narrow viewport while preserving the blade's diagonal arc.
 return {position:[p[0]*side*narrow,p[1],p[2]],rotation:[p[3],p[4]*side,p[5]*side]};
}
