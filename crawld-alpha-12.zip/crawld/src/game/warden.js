import * as T from '../../vendor/three.module.js?v=12';
// Presentation is independent of damage and reward rules.
import {armorSurface,batchArmour} from './armor-look.js?v=12';
export function dressWarden(root,arms,body,head,legs){
 const surface=armorSurface(91),steel=new T.MeshStandardMaterial({color:0x6e7780,map:surface,metalness:.38,roughness:.78}),gold=new T.MeshStandardMaterial({color:0x93876b,map:surface,metalness:.32,roughness:.83}),dark=new T.MeshLambertMaterial({color:0x141e20}),glow=new T.MeshBasicMaterial({color:0xeab273});
 const box=(parent,w,h,d,x,y,z,mat)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),mat);o.position.set(x,y,z);o.userData.armourDetail=true;parent.add(o);return o;};
 box(body,1.04,.80,.86,0,.02,0,steel);box(body,.86,.20,.13,0,.24,.48,gold);
 for(const side of [-1,1]){box(body,.36,.46,.14,side*.30,-.02,.46,steel);for(const y of [-.17,.14])box(body,.05,.05,.035,side*.42,y,.55,gold);}
 box(body,.22,.47,.14,0,.03,.49,dark);for(const y of [-.08,.05,.18])box(body,.08,.045,.02,0,y,.57,glow);
 box(body,1.06,.12,.91,0,-.39,0,gold);
 // A split, ragged mantle breaks up the outline without obscuring the hammer arm.
 for(const side of [-1,1]){box(body,.38,.85,.13,side*.23,-.22,-.51,dark);box(body,.14,.19,.12,side*.33,-.73,-.51,dark);box(body,.32,.38,.10,side*.20,-.54,.39,steel);}
 box(head,.83,.66,.78,0,.03,0,steel);box(head,.91,.14,.85,0,.26,.03,gold);box(head,.70,.12,.06,0,.13,.43,dark);
 for(const side of [-1,1]){box(head,.20,.035,.025,side*.19,.13,.47,glow);box(head,.14,.43,.11,side*.30,-.10,.43,steel);box(head,.11,.14,.12,side*.29,-.38,.41,gold);}
 box(head,.13,.55,.15,0,-.04,.45,steel);box(head,.73,.12,.77,0,-.32,0,steel);
 for(const [x,h]of [[-.31,.33],[0,.48],[.31,.40]]){box(head,.16,h,.22,x,.42+h/2,-.04,steel);box(head,.09,.13,.18,x,.48+h,-.04,gold);}
 for(const side of [-1,1]){const arm=arms[side===-1?0:1];box(arm,.67,.35,.95,side*.06,.02,0,steel);box(arm,.72,.08,1,side*.06,.22,0,gold);box(arm,.18,.34,.26,side*.24,.40,0,steel);box(arm,.09,.20,.18,side*.26,.66,0,gold);box(arm,.39,.38,.43,0,-.44,0,steel);for(const y of [-.31,-.50])box(arm,.42,.07,.45,0,y,0,gold);
 const leg=legs[side===-1?0:1];box(leg,.36,.29,.41,0,-.16,.04,steel);box(leg,.40,.15,.51,0,-.42,.10,steel);box(leg,.42,.06,.52,0,-.49,.10,gold);}
 const hammer=new T.Group();hammer.name='warden-hammer';arms[1].add(hammer);box(hammer,.13,1.15,.13,0,-.35,.05,dark);for(const y of [-.22,-.42])box(hammer,.16,.06,.16,0,y,.05,gold);
 box(hammer,.80,.49,.65,0,-.92,.05,steel);for(const side of [-1,1])box(hammer,.10,.55,.70,side*.37,-.92,.05,gold);box(hammer,.08,.32,.02,0,-.92,.39,glow);for(const x of [-.23,.23])box(hammer,.06,.06,.04,x,-.82,.40,gold);
 batchArmour(root);
 const shock=new T.Mesh(new T.RingGeometry(.92,1,40),new T.MeshBasicMaterial({color:0xffce83,side:T.DoubleSide,transparent:true,opacity:0,depthWrite:false}));shock.rotation.x=-Math.PI/2;shock.position.y=.035;root.add(shock);shock.userData.effect=true;
 return {shock,gold,steel,glow,head};
}
export function animateWarden(e,reduced){const v=e.warden;if(!v)return;const brain=e.brain,a=brain.attack,raw=brain.progress,charge=raw*raw*(3-2*raw),active=brain.state==='active',cut=active?1-brain.remaining/a.active:0,recovery=brain.state==='recovery'?Math.min(1,brain.remaining/.45):0;
 if(e.dead){v.shock.visible=false;return;}
 e.root.position.y=1;
 if(!reduced){
 e.arms[0].rotation.set(.08,0,-.04);e.arms[1].rotation.set(.10,0,.04);
 if(e.windup>0){
 if(a.id==='sweep'){e.arms[1].rotation.set(-charge*.9,-charge*.65,-charge*1.7);e.body.rotation.y=-charge*.22;e.root.rotation.x=-charge*.08;}
 else if(a.id==='charge'){e.arms[0].rotation.x=-1.1;e.arms[1].rotation.x=.35;e.root.rotation.x=charge*.34;e.body.rotation.y=0;}
 else{e.arms[1].rotation.x=-charge*2.8;e.arms[0].rotation.x=-charge*1.1;e.root.rotation.x=-charge*.16;e.body.rotation.y=0;}
 }else if(active){
 if(a.id==='sweep'){e.arms[1].rotation.set(-.9+cut*1.6,-.65+cut*1.2,-1.7+cut*3.2);e.body.rotation.y=-.22+cut*.55;}
 else if(a.id==='charge'){e.arms[0].rotation.x=-1.1;e.arms[1].rotation.x=.35;e.root.rotation.x=.42;}
 else{e.arms[1].rotation.x=-2.8+cut*3.9;e.arms[0].rotation.x=-1.1+cut*1.4;e.root.rotation.x=-.16+cut*.46;}
 }else{e.body.rotation.y*=.82;e.arms[1].rotation.x=.9*recovery;e.root.rotation.x=.18*recovery;if(brain.state==='idle'){const stride=Math.sin(e.timer);e.root.position.y+=Math.abs(stride)*.025;e.arms[0].rotation.x=stride*.15;e.arms[1].rotation.x=-stride*.10;}}
 const recoil=Math.max(0,Math.min(1,e.hit/.27))**2;v.head.rotation.x=-recoil*.16;v.head.rotation.z=-recoil*.12*(e.slashSide??1);e.body.rotation.z=recoil*.12*(e.slashSide??1);e.root.rotation.x-=recoil*.12;
 }else{v.head.rotation.set(0,0,0);e.body.rotation.set(0,0,0);e.arms.forEach(x=>x.rotation.set(0,0,0));e.legs.forEach(x=>x.rotation.set(0,0,0));}
 v.glow.color.setHex(e.windup>0?0xffebbc:brain.enraged?0xff8051:0xffcb79);
 v.steel.emissive.setHex(e.hit>0?0x754a30:brain.enraged?0x451b0a:0);v.steel.emissiveIntensity=e.hit>0?e.hit/.27:brain.enraged?.28:0;
 v.shock.visible=(e.shockTime??0)>0&&a?.id==='slam';v.shock.scale.setScalar(reduced?3.15:3.15*(1-(e.shockTime??0)/.45));v.shock.material.opacity=(e.shockTime??0)/.45*.8;
}
