import * as T from '../../vendor/three.module.js?v=23';
// Face-by-face patina is baked into a single mesh per animated part.
function forge(){const positions=[],normals=[],colors=[];let seed=31;return {box(size,pos,color,angle=0){const g=new T.BoxGeometry(...size,2,Math.max(1,Math.ceil(size[1]*24)),1).toNonIndexed();g.rotateX(angle);g.translate(...pos);const p=g.attributes.position,n=g.attributes.normal,c=new T.Color(color);for(let i=0;i<p.count;i++){if(i%3===0)seed=(seed*1664525+1013904223)>>>0;const shade=.78+(seed%100)/450;positions.push(p.getX(i),p.getY(i),p.getZ(i));normals.push(n.getX(i),n.getY(i),n.getZ(i));colors.push(c.r*shade,c.g*shade,c.b*shade);}g.dispose();},finish(parent,name){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('normal',new T.Float32BufferAttribute(normals,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.computeBoundingSphere();const m=new T.Mesh(g,new T.MeshLambertMaterial({vertexColors:true}));m.name=name;parent.add(m);return m;}};}
const STEEL=[0x626b65,0x8c9997,0x397764,0xa08c55],EDGE=[0xa5aaa0,0xc2c7b7,0x8ebca4,0xc8b47b],TRIM=[0x756046,0x657476,0x405b43,0x9e7847];
export function createSword(tier=0,rare=false){const root=new T.Group(),f=forge(),wide=tier>=2?.17:.14,metal=STEEL[tier],edge=EDGE[tier],trim=TRIM[tier];
 f.box([.085,.34,.10],[0,-.30,0],0x2b2520);
 for(let i=0;i<7;i++)f.box([.098,.018,.115],[0,-.44+i*.043,0],i%2?0x4c3a2b:0x3a3026);
 f.box([.13,.08,.13],[0,-.50,0],trim);f.box([.07,.025,.15],[0,-.50,0],edge);
 f.box([.37+(tier===3?.07:0),.065,.15],[0,-.10,0],trim);
 for(const s of [-1,1]){f.box([.065,.11,.16],[s*(tier===3?.20:.165),-.115,0],metal);f.box([.04,.025,.17],[s*.165,-.075,0],edge);}
 f.box([wide,.65,.07],[0,.26,0],metal);f.box([wide*.54,.11,.055],[0,.64,0],metal);f.box([.038,.045,.035],[0,.705,0],edge);
 for(const s of [-1,1]){f.box([.018,.62,.075],[s*(wide/2-.006),.26,0],edge);f.box([.022,.46,.006],[0,.22,s*.037],0x303d38);f.box([.025,.11,.012],[0,-.025,s*.041],trim);
 for(let i=0;i<8;i++){const x=((i*17)%11-5)*.008,y=.02+i*.072;f.box([.018+(i%3)*.008,.004,.003],[x,y,s*.037],i%3===0&&tier===0?0x794b32:edge);}}
 f.box([.065,.055,.18],[0,-.09,0],trim);f.box([.024,.025,.185],[0,-.085,0],tier>=2?edge:0x353d30);
 if(tier>=2)for(let i=0;i<3;i++)f.box([.025,.017,.077],[0,.18+i*.08,0],edge);
 if(rare)for(let i=0;i<4;i++)f.box([.024,.016,.08],[0,.08+i*.075,0],0xc6a36e);f.finish(root,'weathered-blade');return root;
}
export function createBow(tier=0,rare=false){const root=new T.Group(),wood=[0x514332,0x596665,0x355c49,0x625034][tier],trim=TRIM[tier],edge=EDGE[tier],f=forge();
 f.box([.13,.24,.17],[.31,0,-.20],0x302920);
 for(let i=0;i<6;i++)f.box([.145,.019,.18],[.31,-.10+i*.04,-.20],i%2?0x5c4934:0x44372b);
 for(const side of [-1,1]){f.box([.15,.035,.19],[.31,side*.13,-.20],trim);const limb=new T.Group();limb.name=side>0?'upper-limb':'lower-limb';root.add(limb);const l=forge();for(const [y,z,a]of [[.20,-.16,-.30],[.39,-.075,-.50]]){const angle=side*a;l.box([.085+(tier===3?.025:0),.25,.12],[.28,side*y,z],wood,angle);l.box([.018,.22,.125],[.245,side*y,z],trim,angle);
 for(let i=0;i<3;i++)l.box([.036,.035,.135],[.28,side*(y-.07+i*.065),z],i===1?trim:wood,angle);
 l.box([.012,.14,.004],[.30,side*y,z+.063],edge,angle);}
 l.box([.11,.08,.11],[.28,side*.49,-.015],trim);l.box([.055,.018,.12],[.28,side*.505,-.015],edge);l.box([.025,.04,.13],[.28,side*.43,-.04],edge);l.finish(limb,'laminated-limb');}
 if(rare)for(const side of [-1,1])f.box([.15,.02,.195],[.31,side*.08,-.20],0xc6a36e);f.finish(root,'leather-grip');
 const g=new T.BufferGeometry().setFromPoints([new T.Vector3(.28,-.50,-.015),new T.Vector3(.20,0,.02),new T.Vector3(.28,.50,-.015)]),string=new T.Line(g,new T.LineBasicMaterial({color:0xbab39a}));string.name='bowstring';root.add(string);
 const arrow=new T.Group();arrow.name='loaded-arrow';const a=forge();a.box([.026,.026,1.4],[0,0,-.64],0x7a6749);a.box([.018,.008,1.1],[0,.014,-.64],0xaa9870);a.box([.055,.018,.10],[0,0,.025],0xb4b29c);a.box([.018,.055,.10],[0,0,.025],0x6f7e72);a.box([.065,.065,.10],[0,0,-1.39],0x686f69);a.finish(arrow,'worn-arrow');arrow.position.x=.20;root.add(arrow);return root;
}
