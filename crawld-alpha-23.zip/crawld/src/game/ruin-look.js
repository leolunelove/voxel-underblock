import * as T from '../../vendor/three.module.js?v=23';
// Age collects at the edges; the route and central fighting space remain intact.
export function dressAncientRuins(d,prop){
 let seed=d.seed^8129;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};d.ruinClearances=[];
 const stone=(size,pos,color=0x8b927c,rotation=0)=>{const m=prop(...size,...pos,color);m.material.map=d.textures[1];m.rotation.y=rotation;return m;};
 const collide=m=>{m.updateMatrixWorld(true);const box=new T.Box3().setFromObject(m);d.blockers.push(box);d.ruinClearances.push(box);};
 const root=(from,to,width)=>{const a=new T.Vector3(...from),b=new T.Vector3(...to),delta=b.clone().sub(a),middle=a.clone().lerp(b,.5),m=prop(width,delta.length(),width,...middle.toArray(),0x484631);m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return m;};
 const debrisGeometry=new T.IcosahedronGeometry(1,0),debris=[],matrix=new T.Matrix4(),q=new T.Quaternion();
 for(const [index,r]of d.rooms.entries()){if(r.natural)continue;const radius=r.radius??4,ceiling=r.ceiling??5,cx=r.x+.5,cz=r.z+.5,edge=radius-1.2;
 for(const sx of [-1,1])for(const sz of [-1,1]){
 const x=cx+sx*edge,z=cz+sz*edge,height=2.2+rand()*2.2;collide(stone([.88,.22,.88],[x,1.11,z],0x687564));
 for(let y=1.22;y<height;y+=.63){const h=Math.min(.59,height-y+.2),piece=stone([.68,h,.68],[x+(rand()-.5)*.07,y+h/2,z+(rand()-.5)*.07],0x818a73,(rand()-.5)*.07);collide(piece);}
 const cap=stone([.77,.2,.73],[x,height+.22,z],0x9a9b83,(rand()-.5)*.2);cap.rotation.z=(rand()-.5)*.22;collide(cap);
 // A surviving upper fragment makes the missing shaft visibly legible.
 stone([.65,.7,.65],[x,ceiling-.55,z],0x79836b,.03*sx);
 for(let i=0;i<3;i++){const shard=stone([.35+rand()*.3,.25+rand()*.25,.5+rand()*.35],[x-sx*(.6+rand()*.5),1.16+i*.08,z-sz*(.5+rand()*.7)],0x77816d,rand()*3);shard.rotation.z=(rand()-.5)*.35;collide(shard);}
 const fallen=stone([.58,.55,1.2],[cx+sx*(radius-1),1.3,cz+sz*(radius-2)],0x838b75,sz*.5);collide(fallen);
 for(let i=0;i<11;i++){const x=cx+sx*(radius-.65-rand()*1.1),z=cz+sz*(radius-.65-rand()*1.1);q.setFromEuler(new T.Euler(rand()*.5,rand()*6,rand()*.5));debris.push(new T.Matrix4().compose(new T.Vector3(x,1.08+rand()*.1,z),q.clone(),new T.Vector3(.12+rand()*.25,.08+rand()*.16,.12+rand()*.35)));}
 }
 // Old roots follow masonry seams, split around broken stone and creep along the walls.
 for(const side of [-1,1])for(const corner of [-1,1]){
 const x=cx+side*(radius-.18),z=cz+corner*(radius-1.5),bend=z-corner*.55;
 root([x,ceiling-.2,z],[x-side*.14,ceiling*.6,bend],.18);
 root([x-side*.14,ceiling*.6,bend],[x-side*.26,2.1,z-corner*1.3],.13);
 root([x-side*.26,2.1,z-corner*1.3],[x-side*.6,1.08,z-corner*1.7],.08);
 root([x-side*.13,ceiling*.6,bend],[x-side*.1,ceiling*.45,z+corner*.55],.07);
 root([x-side*.6,1.08,z-corner*1.7],[x-side*.95,1.05,z-corner*2.3],.055);
 const moss=prop(.02,.9,.65,x-side*.03,2.7,z-corner*.5,0x405139);moss.rotation.x=.15*side;
 // Faded carved banding, interrupted rather than pristine continuous trim.
 for(let i=0;i<3;i++)stone([.07,.12,.55],[x-side*.03,4.25+i*.22,z-corner*.2],i===1?0x66745d:0x8b8f75);
 }
 }
 const rubble=new T.InstancedMesh(debrisGeometry,new T.MeshStandardMaterial({color:0x727d67,map:d.textures[3],roughness:1,flatShading:true}),debris.length);rubble.name='ancient-ruin-rubble';debris.forEach((m,i)=>rubble.setMatrixAt(i,m));d.root.add(rubble);
}
