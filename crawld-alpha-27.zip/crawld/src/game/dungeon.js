import {FIRST_ROOMS,firstFloorSpawns,canNotice,dressFirstFloor} from './first-floor.js?v=27';
import {dressAncientRuins} from './ruin-look.js?v=27';
import {caveTexture,dressCaverns,updateCaverns} from './cave-look.js?v=27';
import {dressChest,animateChest} from './chest-look.js?v=27';
import * as T from '../../vendor/three.module.js?v=27';
import {generateDungeon} from './dungeon-rules.js?v=27';
import {MONSTERS} from './hunt-rules.js?v=27';
import {Hunt} from './hunt.js?v=27';
import {stoneTexture,flameTexture,dressDungeon,updateAtmosphere,batchDungeon} from './dungeon-look.js?v=27';
export class Dungeon{
 constructor(scene,state,seed,difficulty=0,floorNumber=3,{linear=true,continuous=false,originZ=100,baseY=0}={}){this.firstFloor=continuous&&floorNumber===1;Object.assign(this,generateDungeon(seed,difficulty,{linear,continuous,originZ,firstFloor:this.firstFloor}));if(this.firstFloor)this.rooms.forEach((r,i)=>{r.style=FIRST_ROOMS[i][0];r.palette=FIRST_ROOMS[i][1];});this.floorNumber=floorNumber;this.baseY=baseY;this.continuous=continuous;this.linear=linear;this.root=new T.Group();scene.add(this.root);this.completed=false;this.cleared=false;this.atExit=false;this.time=0;this.visited=new Set();this.treasures=[];this.secrets=[];this.torches=[];this.blockers=[];this.textures=[stoneTexture(seed),stoneTexture(seed+1,true),flameTexture(),caveTexture(seed)];this.lightPool=Array.from({length:6},()=>{const lamp=new T.PointLight(0xffb963,0,11,2);this.root.add(lamp);return lamp;});
 this.ceilingAt=(x,z)=>this.rooms.find(r=>Math.abs(x-r.x-.5)<(r.radius??4)+1.5&&Math.abs(z-r.z-.5)<(r.radius??4)+1.5)?.ceiling??(linear?6.2:5);
 this.isNaturalAt=(x,z)=>linear&&(this.rooms.find(r=>Math.abs(x-r.x-.5)<(r.radius??4)+1.5&&Math.abs(z-r.z-.5)<(r.radius??4)+1.5)?.natural??true);
 const geometry=new T.BoxGeometry(1,1,1),walls=new Set();for(const key of this.floor){const [x,z]=key.split(',').map(Number);for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1]])if(!this.floor.has((x+dx)+','+(z+dz)))walls.add((x+dx)+','+(z+dz));}
 if(continuous){const south=this.rooms[0].z+5,north=this.rooms.at(-1).z-8;for(let x=-2;x<=2;x++){walls.delete(x+','+south);walls.delete(x+','+north);}}
 const mesh=(cells,h,y,color,texture)=>{const m=new T.InstancedMesh(geometry,new T.MeshStandardMaterial({color,map:texture,roughness:.98}),cells.size),matrix=new T.Matrix4();let i=0;for(const key of cells){const [x,z]=key.split(',').map(Number);matrix.compose(new T.Vector3(x+.5,h===4?(this.ceilingAt(x+.5,z+.5)+1)/2:h===.3?this.ceilingAt(x+.5,z+.5)+.15:y,z+.5),new T.Quaternion(),new T.Vector3(1,h===4?this.ceilingAt(x+.5,z+.5)-1:h,1));m.setMatrixAt(i,matrix);m.setColorAt(i++,new T.Color().setScalar(.85+((x*7+z*13+seed)>>>0)%20/100));}this.root.add(m);};
 const split=cells=>[new Set([...cells].filter(key=>{const [x,z]=key.split(',').map(Number);return this.isNaturalAt(x+.5,z+.5);})),new Set([...cells].filter(key=>{const [x,z]=key.split(',').map(Number);return !this.isNaturalAt(x+.5,z+.5);} ))];const [wildFloor,builtFloor]=split(this.floor),[wildWalls,builtWalls]=split(walls);mesh(wildFloor,1,.5,0x9aa08a,this.textures[3]);mesh(builtFloor,1,.5,0xadb09b,this.textures[0]);mesh(wildWalls,4,3,0x9da58e,this.textures[3]);mesh(builtWalls,4,3,0xb6b8a5,this.textures[1]);mesh(wildFloor,.3,5.15,0x79816e,this.textures[3]);mesh(builtFloor,.3,5.15,0x768477,this.textures[0]);
 const palettes={'Cave threshold':[0x66715e,0xffbb69],Intake:[0x667161,0xffbb69],Cellblock:[0x656c77,0xffbd70],"Overgrown cistern":[0x42684f,0xb7e4a5],"Ember forge":[0x78604d,0xff9d45],"Warden vault":[0x64556e,0xc9a8f1],"Smuggler vault":[0x72614b,0xffcc80],"Moss sanctuary":[0x3e6b58,0x9cdbb8],"Sealed reliquary":[0x5b526e,0xc9acf0]};
 const prop=(w,h,d,x,y,z,color,glow=false)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),glow?new T.MeshBasicMaterial({color}):new T.MeshStandardMaterial({color,roughness:.9}));o.position.set(x,y,z);this.root.add(o);return o;};
 const torch=(x,z,color,phase)=>{
 prop(.12,.52,.12,x,2.8,z,0x352d22);prop(.35,.12,.35,x,2.97,z,0x282d2b);
 for(const dx of [-.14,.14])for(const dz of [-.14,.14])prop(.045,.37,.045,x+dx,3.16,z+dz,0x282c28);
 prop(.36,.06,.36,x,3.35,z,0x373a30);
 const flame=prop(.17,.28,.17,x,3.13,z,color,true),core=prop(.09,.23,.10,x,3.14,z,0xffe1a0,true),tip=prop(.08,.16,.08,x+.035,3.33,z,color,true);
 const halo=new T.Sprite(new T.SpriteMaterial({map:this.textures[2],color:0xffb664,transparent:true,blending:T.AdditiveBlending,depthWrite:false,opacity:.55}));halo.position.set(x,3.2,z);halo.scale.set(1.15,1.45,1);this.root.add(halo);
 this.torches.push({flame,core,tip,halo,phase});};
 for(const [i,r]of this.rooms.entries()){if(i===this.rooms.length-1&&floorNumber<3&&!this.firstFloor)r.style=floorNumber===1?'Cellblock':'Ember forge';const [stone,light]=palettes[r.palette??r.style];
 if(!linear&&!r.natural)for(const dx of [-1,1].map(s=>s*((r.radius??4)-.35)))for(const dz of [-1,1].map(s=>s*((r.radius??4)-.35))){const pillar=prop(.6,(r.ceiling??5)-1.2,.6,r.x+.5+dx,((r.ceiling??5)+1)/2-.1,r.z+.5+dz,stone);pillar.material.map=this.textures[1];this.blockers.push(new T.Box3(new T.Vector3(r.x+.5+dx-.3,1,r.z+.5+dz-.3),new T.Vector3(r.x+.5+dx+.3,(r.ceiling??5),r.z+.5+dz+.3)));}
 if(r.natural){const next=this.rooms[1],dx=Math.sign(next.x-r.x),dz=Math.sign(next.z-r.z);for(const side of [-1,1]){torch(r.x+.5+dz*side*2.7,r.z+.5+dx*side*2.7,0xffbb72,i+side);this.torches.at(-1).power=18;}}else{const radius=r.radius??4;torch(r.x+.5-radius+.25,r.z-2.7,0xffb765,i);torch(r.x+.5+radius-.25,r.z+3,0xffc17a,i+2);}
 for(const side of [-1,1])for(let k=-2;k<=2;k++){if(r.style==='Cellblock'&&!this.floor.has((r.x+side*5)+','+(r.z+Math.round(k*.6))))prop(.10,2.5,.10,r.x+.5+side*4.05,2.3,r.z+.5+k*.6,0x819086);if(r.style==='Ember forge')prop(.35,.02,.35,r.x+.5+side*3,1.015,r.z+.5+k,0xd69d52,true);}
 if(i===0&&!r.natural){for(const dx of [-2,2])prop(.5,.4,.5,r.x+.5+dx,1.2,r.z+2.5,0x766244);}
 
 }
 for(const [i,l]of this.links.entries()){const a=this.rooms[l.a],b=this.rooms[l.b];if(!l.secret){const dx=Math.sign(b.x-a.x),dz=Math.sign(b.z-a.z);torch((a.x+b.x)/2+.5+dz*(linear?2.35:1.32),(a.z+b.z)/2+.5-dx*(linear?2.35:1.32),0xffbc70,i+4);}
 else{const dx=Math.sign(b.x-a.x),dz=Math.sign(b.z-a.z),x=a.x+.5+dx*5.35,z=a.z+.5+dz*5.35,gate=prop(dx?.28:3,4,dz?.28:3,x,3,z,0x656c5c);gate.material.map=this.textures[1];gate.material.needsUpdate=true;const box=new T.Box3().setFromObject(gate);this.blockers.push(box);const clue=new T.Group();this.root.add(clue);for(let j=0;j<3;j++){const shard=prop(dx?.04:.12,.08,dz?.04:.12,x-dx*.16+(dz?(j-1)*.1:0),2.25+j*.13,z-dz*.16+(dx?(j-1)*.1:0),0xa49362,true);clue.attach(shard);}this.secrets.push({link:l,gate,box,clue,opened:false,position:new T.Vector3(x,2.65,z)});}}
 for(const [i,room]of this.rooms.entries()){if(room.kind==='main')continue;const shrine=room.kind==='shrine',x=room.x+2.2,z=room.z+2.2;
 const mesh=prop(shrine?.7:.95,shrine?1.25:.8,shrine?.7:.8,x,shrine?1.625:1.4,z,shrine?0x5a9680:room.kind==='secret'?0x7a5f91:0xa27843);
 const lid=prop(shrine?.45:1.02,shrine?.3:.14,shrine?.45:.87,x,shrine?2.4:1.88,z,shrine?0x9cdbb8:room.kind==='secret'?0xd4b2ee:0xe0c07c,shrine);
 if(!shrine)dressChest(mesh,lid,room.kind==='secret');
 this.treasures.push({id:i,room:i,kind:room.kind,mesh,lid,claimed:false});}
 dressDungeon(this,prop);if(linear){dressCaverns(this);dressAncientRuins(this,prop);if(this.firstFloor)dressFirstFloor(this,prop);}
 const last=this.rooms.at(-1);this.exit=prop(1.6,2.6,.25,last.x+.5,2.3,continuous?last.z-6:last.z+3,0x4a4b40,true);prop(2,.25,.5,last.x+.5,3.7,continuous?last.z-6:last.z+3,0x9b8a62);
 this.cacheRoom=this.firstFloor?0:continuous?2:1;this.cacheClaimed=false;const c=this.rooms[this.cacheRoom],cacheX=this.firstFloor?c.x+2.7:continuous?c.x-2.7:c.x+2.7;this.cache=prop(.8,.7,.7,cacheX,1.35,c.z+(this.firstFloor?1.5:2.7),0xac8050);this.cacheLid=prop(.87,.15,.77,cacheX,1.78,c.z+(this.firstFloor?1.5:2.7),0xd3b679);
 dressChest(this.cache,this.cacheLid);
 this.encounters=this.firstFloor?firstFloorSpawns(this):[];
 const spawns=this.firstFloor?this.encounters.map(s=>[s.id,s.x,s.z,s.type]):this.rooms.flatMap((r,i)=>i===0||r.kind==='shrine'||(!continuous&&r.kind==='secret')?[]:[[i,r.x+.5,r.z+.5,i===this.rooms.length-1?(floorNumber===3?2:1):continuous?(i===1?0:1):i%2]]);
 this.combat=new Hunt(scene,state,{spawns,floorY:1+baseY,statsFor:(type,id)=>{const source=MONSTERS[type],m=this.firstFloor&&id===105?{...source,name:'The Gatekeeper',hp:118,damage:26,xp:42,value:70}:source,scale=1+(floorNumber-1)*.1;return {...m,hp:Math.round(m.hp*this.rules.health*scale),damage:Math.round(m.damage*this.rules.damage),xp:Math.round(m.xp*this.rules.reward),value:Math.round(m.value*this.rules.reward)};},active:()=>true,respawn:false,boundsFor:e=>{if(!this.firstFloor)return [e.x-3.1,e.x+3.1,e.z-3.1,e.z+3.1];const r=this.rooms[this.encounters.find(s=>s.id===e.id).room],radius=r.radius-1;return [r.x+.5-radius,r.x+.5+radius,r.z+.5-radius,r.z+.5+radius];},walkable:this.firstFloor?p=>this.enemyFits(p):null,canHit:this.firstFloor?(e,p)=>{const a=e.root.position.clone().add(new T.Vector3(0,1.1,0)),delta=p.clone().sub(a);return !this.blocked(new T.Ray(a,delta.clone().normalize()),delta.length());}:null,canAct:(e,p)=>this.firstFloor?canNotice(this,e,p):this.roomAt(p)>=0&&this.roomAt(p)===this.roomAt(e.root.position)});
 if(this.firstFloor)for(const e of this.combat.enemies){e.required=e.id===105;if(e.required)e.root.children.forEach(o=>{o.position.multiplyScalar(1.12);o.scale.multiplyScalar(1.12);});}
 batchDungeon(this);this.root.position.y=baseY;for(const b of this.blockers)b.translate(new T.Vector3(0,baseY,0));
 }
 enemyFits(p){for(const dx of [-.32,.32])for(const dz of [-.32,.32])if(this.solid(p.x+dx,1.25+this.baseY,p.z+dz)||this.blockers.some(b=>b.containsPoint(new T.Vector3(p.x+dx,1.25+this.baseY,p.z+dz))))return false;return true;}
 secretAvailable(p){return this.secrets.find(s=>!s.opened&&p.distanceTo(s.position)<2.6);}
 revealSecret(s){if(!s||s.opened)return false;s.opened=true;s.link.opened=true;s.gate.visible=false;s.clue.visible=false;const n=this.blockers.indexOf(s.box);if(n>=0)this.blockers.splice(n,1);return true;}
 treasureAvailable(p){return this.treasures.find(t=>!t.claimed&&p.distanceTo(new T.Vector3(t.mesh.position.x,2.65+this.baseY,t.mesh.position.z))<2&&!this.combat.enemies.some(e=>!e.dead&&(this.firstFloor?Math.hypot(e.root.position.x-t.mesh.position.x,e.root.position.z-t.mesh.position.z)<4.2:this.roomAt(e.root.position)===t.room)));}
 claimTreasure(t){if(t.claimed)return;t.claimed=true;t.mesh.material.color.setHex(0x4e4b42);if(t.kind==='shrine')t.lid.material.color.setHex(0x405b4e);}
 passages(index){return this.links.filter(l=>(!l.secret||l.opened)&&(l.a===index||l.b===index)).map(l=>l.a===index?l.b:l.a);}
 roomAt(p){return this.rooms.findIndex(r=>Math.abs(p.x-r.x-.5)<(r.radius??4)+.5&&Math.abs(p.z-r.z-.5)<(r.radius??4)+.5);}
 solid(x,y,z){return y<1+this.baseY||y>this.ceilingAt(x,z)+this.baseY||(!this.floor.has(Math.floor(x)+','+Math.floor(z))&&y<7);}
 obstructed(ray,distance){return this.blocked(ray,distance);}
 blocked(ray,distance){for(let d=.1;d<distance;d+=.12){const p=ray.at(d,new T.Vector3());if(this.solid(p.x,p.y,p.z)||this.blockers.some(b=>b.containsPoint(p)))return true;}return false;}
 cacheAvailable(p){return !this.cacheClaimed&&p.distanceTo(new T.Vector3(this.cache.position.x,2.65+this.baseY,this.cache.position.z))<2&&!this.combat.enemies.some(e=>!e.dead&&(this.firstFloor?Math.hypot(e.root.position.x-this.cache.position.x,e.root.position.z-this.cache.position.z)<4.2:this.roomAt(e.root.position)===this.cacheRoom));}
 claimCache(){this.cacheClaimed=true;this.cache.material.color.setHex(0x5b4a36);}
 update(position,dt=0,reduced=false){this.time+=dt;for(const t of this.treasures)if(t.kind!=='shrine')animateChest(t.mesh,t.lid,t.claimed,dt,reduced);animateChest(this.cache,this.cacheLid,this.cacheClaimed,dt,reduced);const room=this.roomAt(position);if(room>=0)this.visited.add(room);this.cleared=this.combat.enemies.every(e=>e.dead||(this.firstFloor?!e.required:!this.rooms[this.roomAt(e.root.position)]?.critical));this.atExit=position.distanceTo(new T.Vector3(this.exit.position.x,2.65+this.baseY,this.exit.position.z))<1.9;this.exit.material.color.setHex(this.cleared?0xe0c578:0x4a4b40);for(const t of this.torches){const pulse=reduced?1:1+Math.sin(this.time*8+t.phase)*.08+Math.sin(this.time*17+t.phase)*.035;t.flame.scale.set(1,pulse,1);t.tip.scale.y=pulse;t.halo.material.opacity=reduced?.45:.45+pulse*.06;}updateAtmosphere(this,position,reduced,dt);updateCaverns(this,position,reduced);}
 dispose(){this.combat.dispose();this.root.removeFromParent();const gs=new Set(),ms=new Set();this.root.traverse(o=>{if(o.geometry)gs.add(o.geometry);if(o.material)ms.add(o.material);if(o.isInstancedMesh)o.dispose();});gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());this.textures.forEach(t=>t.dispose());}
}
