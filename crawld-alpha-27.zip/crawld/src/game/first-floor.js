import * as T from '../../vendor/three.module.js?v=27';
export const FIRST_ROOMS=[['Collapsed approach','Cave threshold'],['Abandoned stores','Smuggler vault'],['Rootwater cistern','Moss sanctuary'],['Broken barracks','Sealed reliquary'],['Gatekeeper’s hall','Cellblock']];
export function firstFloorSpawns(d){const flip=d.seed%2?1:-1,at=(id,room,x,z,type,notice,guardian=false)=>({id,room,x:d.rooms[room].x+.5+x*flip,z:d.rooms[room].z+.5+z,type,notice,guardian});return [at(100,1,-2.5,.4,0,6),at(101,1,3.6,-2.6,0,4.8),at(102,2,3.4,-1.8,0,2.8),at(103,3,-2.8,-1.8,1,6),at(104,3,2.4,2.1,0,4),at(105,4,1.5,-2.3,1,9,true)];}
export function canNotice(d,e,p){
 const distance=Math.hypot(e.root.position.x-p.x,e.root.position.z-p.z),plan=d.encounters.find(s=>s.id===e.id);
 if(!plan)return false;
 if(e.hit>0)e.awake=true;
 if(!e.awake&&distance<plan.notice){const start=e.root.position.clone().add(new T.Vector3(0,1.1,0)),end=p.clone().sub(start);e.awake=!d.blocked(new T.Ray(start,end.clone().normalize()),end.length());}
 return !!e.awake&&distance<14;
}
export function dressFirstFloor(d,prop){
 const flip=d.seed%2?1:-1,box=(r,x,z,w,h,depth,color,angle=0,solid=false)=>{const m=prop(w,h,depth,r.x+.5+x*flip,1+h/2,r.z+.5+z,color);m.rotation.y=angle*flip;if(solid){m.updateMatrixWorld(true);d.blockers.push(new T.Box3().setFromObject(m));}return m;};
 const [entrance,stores,cistern,barracks,hall]=d.rooms;
 // A failed expedition left its belongings by the way in, not in the walking line.
 box(entrance,-2.7,1.8,1.25,.18,1.9,0x514e34,.14);box(entrance,-2.7,.4,.65,.55,.6,0x66533a,.15,true);
 for(const [x,z,h,a]of [[-3.5,2,1.2,.08],[-4.5,1.7,.7,-.14],[-3.7,-.2,.5,.3],[3.7,3.4,.85,-.12]]){box(stores,x,z,.95,h,.9,0x66563d,a,true);box(stores,x,z,1.04,.08,1,0x343b2d,a);}
 // The failed drain and broken lifting gear explain the damp, overgrown chamber.
 for(const z of [-2,0,2])box(cistern,-2.1,z,.35,.025,1.8,0x253e34);
 box(cistern,-3.7,-1,.9,.6,1.5,0x68735a,.08,true);
 const beam=prop(.18,2.4,.18,cistern.x+.5-3.5*flip,3.2,cistern.z-1.2,0x343b2d);beam.rotation.z=.17;
 for(let i=0;i<4;i++)prop(.12,.24,.12,cistern.x+.5-3.5*flip,2.3+i*.27,cistern.z-1.2,0x404737);
 // Barracks furnishings have fallen toward one wall; the centre remains a route.
 for(const z of [-2.5,.1,2.5]){box(barracks,4.1,z,1.4,.26,1.8,0x494b36,.09,true);box(barracks,4.1,z,1.15,.14,1.6,0x62634a,-.06);}
 box(barracks,-4,1.9,.3,1.5,2.2,0x4a4432,-.23,true);
 for(let i=0;i<4;i++){const sword=box(barracks,-3.8+i*.19,1.9,.07,.75,.08,0x77816a);sword.rotation.z=.3;}
 // Scored stone and discarded shields lead toward the old keeper's post.
 for(let i=0;i<9;i++){const z=barracks.z-4-i*1.5;const scar=prop(.055,.012,.8,.5+(i%2?1.1:-1.1),1.013,z,0x393e30);scar.rotation.y=.15;}
 for(const side of [-1,1]){box(hall,side*4.5,1.8,.85,.13,1.15,0x424c40,.35);box(hall,side*5.6,-2,.55,2,.65,0x67705a,.1,true);}
 box(hall,-4.8,-3.8,1.5,.8,1.1,0x555d4b,-.1,true);
 // Loot uses different, plausible hiding places instead of one repeated pedestal.
 for(const t of d.treasures){const r=d.rooms[t.room],[x,z]=t.kind==='treasure'?[-4.2,-2.9]:t.kind==='shrine'?[-3.4,2.3]:[3.5,-3.4],dx=r.x+.5+x*flip-t.mesh.position.x,dz=r.z+.5+z-t.mesh.position.z;t.mesh.position.x+=dx;t.mesh.position.z+=dz;t.lid.position.x+=dx;t.lid.position.z+=dz;}
}
