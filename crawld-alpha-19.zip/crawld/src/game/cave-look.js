import * as T from '../../vendor/three.module.js?v=19a';
export function caveTexture(seed){const size=64,data=new Uint8Array(size*size*4);let n=seed>>>0;for(let y=0;y<size;y++)for(let x=0;x<size;x++){n=(Math.imul(n,1664525)+1013904223)>>>0;const shade=111+n%27+Math.sin(y*.37+x*.06)*9,i=(y*size+x)*4;data[i]=shade*.85;data[i+1]=shade;data[i+2]=shade*.84;data[i+3]=255;}const t=new T.DataTexture(data,size,size);t.colorSpace=T.SRGBColorSpace;t.magFilter=t.minFilter=T.NearestFilter;t.needsUpdate=true;return t;}
export function dressCaverns(d){
 let seed=d.seed;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};const geometry=new T.IcosahedronGeometry(1,0),positions=geometry.attributes.position,colors=[];for(let i=0;i<positions.count;i++){const v=.7+(Math.floor(i/3)%6)*.045;colors.push(v*.93,v,v*.86);}geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));const matrices=[],quaternion=new T.Quaternion(),rotation=new T.Euler();
 const rock=(x,y,z,w,h,depth)=>{quaternion.setFromEuler(rotation.set((rand()-.5)*.5,rand()*6,(rand()-.5)*.6));matrices.push(new T.Matrix4().compose(new T.Vector3(x,y,z),quaternion.clone(),new T.Vector3(w,h,depth)));};
 // Every corridor keeps a generous clear core; rock intrudes only at the shoulders.
 for(const link of d.links){if(link.secret)continue;const a=d.rooms[link.a],b=d.rooms[link.b],dx=Math.sign(b.x-a.x),dz=Math.sign(b.z-a.z),distance=Math.abs(a.x-b.x)+Math.abs(a.z-b.z);for(let k=(a.radius??4)+.5;k<distance-(b.radius??4);k+=1.35){const x=a.x+.5+dx*k,z=a.z+.5+dz*k;for(const side of [-1,1]){rock(x+dz*side*3.3,2.8,z+dx*side*3.3,dx?1.25:1.1,2+rand()*.55,dz?1.25:1.1);rock(x+dz*side*2.4,5.8,z+dx*side*2.4,1.5,.85+rand()*.25,1.5);}rock(x,6.2,z,1.5,.5,1.5);}}
 for(const r of d.rooms){const neighbors=d.links.filter(l=>d.rooms[l.a]===r||d.rooms[l.b]===r).map(l=>d.rooms[l.a]===r?d.rooms[l.b]:d.rooms[l.a]);const radius=r.radius??4,ceiling=r.ceiling??5,cx=r.x+.5,cz=r.z+.5;
 // The opening chamber is all rock. Ruins retain masonry between broken buttresses.
 for(const side of [-1,1])for(let k=-radius;k<=radius;k+=1.8){if(r.natural||rand()>.45){if(!neighbors.some(n=>Math.sign(n.x-r.x)===side&&n.z===r.z&&Math.abs(k)<3.4))rock(cx+side*(radius+.5),2.9,cz+k,1.5,2.4,1.5);if(!neighbors.some(n=>Math.sign(n.z-r.z)===side&&n.x===r.x&&Math.abs(k)<3.4))rock(cx+k,2.9,cz+side*(radius+.5),1.5,2.4,1.5);}if(r.natural){rock(cx+side*(radius-.6),ceiling-.25,cz+k,1.8,.8,1.6);rock(cx+k,ceiling-.25,cz+side*(radius-.6),1.6,.8,1.8);}}
 if(r.natural)for(let x=-2;x<=2;x+=2)for(let z=-2;z<=2;z+=2)rock(cx+x,ceiling+.1,cz+z,1.8,.55,1.8);
 // Small rubble lies flush with the floor, clear of the fighting and walking plane.
 for(let i=0;i<22;i++){const side=i%2?1:-1,x=cx+side*(radius-1+rand()*.6),z=cz+(rand()-.5)*radius*1.7;rock(x,1.03,z,.12+rand()*.3,.055,.12+rand()*.3);}
 }
 const mesh=new T.InstancedMesh(geometry,new T.MeshStandardMaterial({color:0x778273,roughness:1,flatShading:true,vertexColors:true}),matrices.length);mesh.name='rugged-cave-shell';matrices.forEach((m,i)=>mesh.setMatrixAt(i,m));d.root.add(mesh);
}
