export const inRange=p=>p.x>20.5&&p.x<38.5&&p.z>3.5&&p.z<14.5;
export const atDungeonGate=p=>p.x< -24&&p.x> -29&&Math.abs(p.z-8)<2;
export const skillLevel=xp=>Math.min(20,1+Math.floor(Math.sqrt(Math.max(0,xp)/30)));
export const shotXP=(charge,radius)=>charge<.18?0:radius<.22?6:radius<.5?4:2;
export const DIFFICULTIES=[{name:"Scavenger",health:1,damage:1,reward:1,bonus:80},{name:"Lockdown",health:1.55,damage:1.3,reward:2,bonus:220},{name:"Blacksite",health:2.2,damage:1.65,reward:3.5,bonus:500}];
export function generateDungeon(seed,difficulty=0){
 let n=seed>>>0;const random=()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;},dirs=[[1,0],[-1,0],[0,1],[0,-1]],mainCount=4+Math.floor(random()*2);
 const main=[{x:100,z:100,kind:'main',critical:true}],occupied=new Set(['100,100']),rawLinks=[];
 for(let i=1;i<mainCount;i++){const a=main[i-1],choices=dirs.filter(([dx,dz])=>!occupied.has((a.x+dx*12)+','+(a.z+dz*12))),[dx,dz]=choices[Math.floor(random()*choices.length)];const b={x:a.x+dx*12,z:a.z+dz*12,kind:'main',critical:true};occupied.add(b.x+','+b.z);main.push(b);rawLinks.push({a,b,secret:false});}
 const branches=[];const addBranch=(kind,preferred)=>{const hosts=[main[preferred],...main.slice(1,-1),main[0]],options=[];for(const host of [...new Set(hosts)])for(const [dx,dz]of dirs){const x=host.x+dx*12,z=host.z+dz*12;if(!occupied.has(x+','+z))options.push({host,x,z});}const preferredOptions=options.filter(c=>c.host===main[preferred]),pool=preferredOptions.length?preferredOptions:options,c=pool[Math.floor(random()*pool.length)];if(!c)return;const room={x:c.x,z:c.z,kind,critical:false};occupied.add(room.x+','+room.z);branches.push(room);rawLinks.push({a:c.host,b:room,secret:kind==='secret'});};
 addBranch('treasure',1);addBranch('shrine',2);addBranch('secret',1);
 const rooms=[...main.slice(0,-1),...branches,main.at(-1)],links=rawLinks.map(l=>({a:rooms.indexOf(l.a),b:rooms.indexOf(l.b),secret:l.secret})),floor=new Set(),add=(x,z)=>floor.add(x+','+z);
 for(const room of rooms)for(let x=-4;x<=4;x++)for(let z=-4;z<=4;z++)add(room.x+x,room.z+z);
 for(const l of links){const a=rooms[l.a],b=rooms[l.b],dx=Math.sign(b.x-a.x),dz=Math.sign(b.z-a.z);for(let k=0;k<=12;k++)for(let w=-1;w<=1;w++)add(a.x+dx*k+(dz?w:0),a.z+dz*k+(dx?w:0));}
 const tier=Math.max(0,Math.min(2,Math.trunc(difficulty)||0)),rules=DIFFICULTIES[tier];
 rooms.forEach((room,i)=>room.style=i===0?'Intake':i===rooms.length-1?'Warden vault':room.kind==='treasure'?'Smuggler vault':room.kind==='shrine'?'Moss sanctuary':room.kind==='secret'?'Sealed reliquary':['Cellblock','Overgrown cistern','Ember forge'][(i+(seed>>>0))%3]);
 return {seed:seed>>>0,rooms,links,floor,difficulty:tier,rules,bonus:rules.bonus,xp:Math.round((80+mainCount*20)*rules.reward)};
}
export function finishDungeon(run,skills){if(run.completed||!run.cleared||!run.atExit)return 0;run.completed=true;skills.dungeonXP+=run.xp;skills.completions++;skills.loot=(skills.loot??0)+(run.bonus??0);return run.xp;}
