# Crawld / Doorway branding

Implemented in Alpha 08. The accepted mockup guides the main menu and gameplay HUD. The gameplay world remains the existing playable voxel dungeon.

## Assets

- `assets/crawld-wordmark.svg`: code-native stone pixel wordmark, with an amber doorway in the A.
- `assets/crawld-icon.svg`: doorway favicon.
- `assets/items.svg`: crisp sword, bow, tonic, skills and coin symbols.
- `assets/crawld-menu.png`: generated doorway background, made with the built-in image-generation tool. Original generation preserved in the Codex generated-images folder.

## Final generation prompt

Create a production game MAIN MENU BACKGROUND for CRAWLD, no UI, NO TEXT, NO LETTERS, no logos. Wide landscape 16:9 composition. Closely match this described art direction: richly detailed voxel dungeon ruins, carved square stone bricks, moss, deep dark teal-green shadows, golden amber torch flames. Large ancient rectangular doorway with a squared arch opening occupying right 60% of image at x65%, leading into blackness and a tiny distant warm light. Two chunky metal torch brackets flanking the doorway, one near centre and one at far right. Stone steps and rubble foreground, mossy weathered blocks, smoky subtle air. LEFT 40% must be mostly very dark, low contrast, barely visible masonry, deliberately reserved as negative space for a separate logo and menu overlay; no bright objects there. Ground dull worn stone, restrained reflections. Pixel-art voxel 3D game render, clear block geometry, crunchy pixel textures, cinematic localized torchlight, indie dungeon crawler art, not photorealistic, not smooth fantasy painting, no monsters, no weapons, no HUD, no border. Beautiful atmosphere and highly readable composition at desktop screen size. Palette soot black, muted moss, bone stone, warm amber. The torch glow should frame the dark doorway rather than overexpose it.
