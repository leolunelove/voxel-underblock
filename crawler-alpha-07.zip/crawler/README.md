# crawler
Playable dungeon crawler alpha 04. Built locally on 21 October 2026.

## Start
Extract the whole ZIP before launching.
- macOS: double-click **Play crawler.command**. If your system does not allow that launcher, open Terminal in this folder and run `python3 launch.py`.
- Windows: run **Play crawler.bat** (requires Python 3).
- Linux: run `python3 launch.py`.
The launcher starts a local server on an available port from 4326–4339 and opens your browser. Keep the terminal open while playing; Ctrl+C stops it.
Python 3 is required for the included launcher. No downloads, npm installation or game account are needed. Alternatively serve this folder with any static HTTP server. Opening index.html directly from the filesystem is not supported because browsers restrict JavaScript modules.

## The game
This is the NEW dungeon crawler, not the prison mining game.
Prepare in the refuge menu, choose a difficulty, descend through three randomly generated floors, defeat the Underwarden on the third floor, and use the final gold seal to extract.
Each floor starts in a safe intake. Follow the torchlit passages, clear every enemy, then press E near the exit seal to descend. Health, tonics and risky loot carry between floors.
Room styles include cellblocks, overgrown cisterns, ember forges and the Warden vault. Supply chests in the second room provide a tonic and relic coins after its guard dies. Press E near a chest to open it.
Attack and Archery XP are earned by their respective weapon kills. Dungeoneering XP and the completion bonus require a successful final extraction.
Banked credits buy permanent swords and bows at skill levels 2, 4 and 7. Higher difficulties increase monster health, damage and loot.

## Controls
WASD — move
Mouse — look (right-drag or arrow keys if pointer capture is unavailable)
Hold left mouse — sword slash
Q — switch sword / bow
Hold left mouse with bow — draw; release — shoot
Space — jump (also useful against the boss slam)
Shift — sprint
H — drink a tonic, healing up to 40 HP
E — open a nearby cleared cache or use the exit seal
Tab — skills / return to the run
Escape — pause
R — retreat confirmation; abandoning loses your risky loot

## Saves and risk
Skills, forged gear and banked credits save locally in this browser, under a new storage key separate from the prison game. Defeat, abandoning and reloading lose the current haul. Runs do not resume after closing or reloading. Clearing browser data erases progress. Changing the host/port or browser uses a separate save.
The ZIP contains no test saves or personal data.

## Verification
- Automated rule and integration checks cover connected generation, walkable corridors, sword timing, wall obstruction, real arrows, boss windup/dodge, healing, cache limits, difficulty scaling, extraction, defeat, save validation and forging.
- A complete three-floor Scavenger run, boss defeat, extraction, sword forging, pause, healing, retreat and persistence after reload were exercised in the local browser.
- First playable slice: a compact chain of rooms per floor, two regular enemy types and one boss. No inventory grid, random weapon affixes, multiplayer or mid-run saves.
- Audio cues are synthesized locally; they trigger on actions but subjective sound and combat feel still need your playtest.
- Desktop keyboard and mouse are required. Touch controls and physical Windows/Linux launcher execution have not been tested.

## Source / tests
Game source is included in src/. With Node.js installed, run `node --test tests/*.test.js`.
Three.js is bundled locally; its license is in vendor/LICENSE-three.txt.
The Voxel pixel font and original tool/monster geometry are retained from the existing Voxel prototype. Dungeon crawler entry point, menus, run rules and torchlit world are separate from the old game.

## Alpha 02 / sword feel
Alternating diagonal cuts with continuous follow-through replace the mining-style chop. A successful sword contact holds the attack clock for 38 ms, while movement and looking stay live. Armour, flesh and finishing blows use different synthesized impact layers; repeated swings vary slightly in pitch. Regular monsters twist, flinch and fall with the direction of the cut; the boss retains its resistance to stagger. Reduced motion keeps the weapon on one side with minimal movement.
11 automated checks pass. Browser sword kills and pause were rechecked without console errors; subjective sound mix still needs your listening test.

## Alpha 03 / monster encounters
Crypt crawlers crouch and pounce at a fixed marked position; move off the circle. Ironbacks alternate a heavy overhead and quicker bash; late windups resist interruption. The Underwarden cycles an amber ground slam (jump or backstep), pink forward hammer sweep (get behind or backstep), and cyan straight charge (sidestep). Charge lanes stop at the arena boundary. Below half health he becomes enraged with faster tells and recovery, while keeping clear openings.
Telegraphs lock their direction when the attack begins, so dodging is deliberate rather than chasing the cursor. Damage occurs once at the committed impact; visual effects never award damage. Reduced motion retains attack markers and labels.
16 automated checks cover attack sequences, all hit shapes, windup timing, interruption resistance, enrage and real boss markers. A full three-floor browser run, enraged boss defeat and extraction were repeated without console errors.

## Alpha 04 / exploration
Each seeded floor now has a main route plus a guarded smuggler-vault branch, a restoration sanctuary and a hidden reliquary. Room connections form a real junction graph; compass hints show adjacent unexplored routes and names of visited rooms. Side-room enemies are optional and do not keep the exit seal locked. The final guardian still blocks progression.
Inspect the unusual masonry with three small glowing cracks near a junction. Press E nearby to open it, then walk into the secret chamber. Hidden doors physically block walking and arrows before discovery.
Smuggler chests award 75 credits per floor depth, multiplied by difficulty. Secret reliquaries award 140 per floor depth, multiplied by difficulty, plus a tonic and Ember Edge (+20% sword and bow damage for the current floor). These coins remain at risk until extraction. Restoration sanctuaries restore up to 35 HP once per floor; full health does not consume the shrine. Every treasure is one-time. Descending clears Ember Edge.
20 automated tests pass, including 300 seeded layouts, branch connectivity, secret-door collision, optional-guard extraction rules and reward limits. Browser checks covered a guarded treasure detour, returning to the main route, discovering and entering a secret room, and receiving its coins, tonic and weapon boost without console errors.
