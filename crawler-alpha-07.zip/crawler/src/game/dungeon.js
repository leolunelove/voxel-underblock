import * as T from '../../vendor/three.module.js?v=07';
import {generateDungeon} from './dungeon-rules.js?v=07';
import {MONSTERS} from './hunt-rules.js?v=07';
import {Hunt} from './hunt.js?v=07';
function stoneTexture(seed,brick=false){const data=new Uint8Array(32*32*4);let n=seed;for(let y=0;y<32;y++)for(let x=0;x<32;x++){n=(Math.imul(n,1664525)+1013904223)>>>0;const seam=brick?(y%8===0||(x+(Math.floor(y/8)%2)*8)%16===0):(x===0||y===0),v=seam?56:132+(n%48);const i=(y*32+x)*4;data[i]=v;data[i+1]=v;data[i+2]=v;data[i+3]=255;}const t=new T.DataTexture(data,32,32);t.magFilter=t.minFilter=T.NearestFilter;t.needsUpdate=true;return t;}
export class Dungeon{
 constructor(scene,state,seed,difficulty=0,floorNumber=3){Object.assign(this,generateDungeon(seed,difficulty));this.floorNumber=floorNumber;this.root=new T.Group();scene.add(this.root);this.completed=false;this.cleared=false;this.atExit=false;this.time=0;this.visited=new Set();this.treasures=[];this.secrets=[];this.torches=[];this.blockers=[];this.textures=[stoneTexture(seed),stoneTexture(seed+1,true)];
 const geometry=new T.BoxGeometry(1,1,1),walls=new Set();for(const key of this.floor){const [x,z]=key.split(',').map(Number);for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1]])if(!this.floor.has((x+dx)+','+(z+dz)))walls.add((x+dx)+','+(z+dz));}
 const mesh=(cells,h,y,color,texture)=>{const m=new T.InstancedMesh(geometry,new T.MeshStandardMaterial({color,map:texture,roughness:.98}),cells.size),matrix=new T.Matrix4();let i=0;for(const key of cells){const [x,z]=key.split(',').map(Number);matrix.compose(new T.Vector3(x+.5,y,z+.5),new T.Quaternion(),new T.Vector3(1,h,1));m.setMatrixAt(i,matrix);m.setColorAt(i++,new T.Color().setScalar(.85+((x*7+z*13+seed)>>>0)%20/100));}this.root.add(m);};
 mesh(this.floor,1,.5,0x7e8170,this.textures[0]);mesh(walls,4,3,0x7c8072,this.textures[1]);mesh(this.floor,.3,5.15,0x48564b,this.textures[0]);
 const palettes={Intake:[0x667161,0xffbb69],Cellblock:[0x656c77,0xffbd70],"Overgrown cistern":[0x42684f,0xb7e4a5],"Ember forge":[0x78604d,0xff9d45],"Warden vault":[0x64556e,0xc9a8f1],"Smuggler vault":[0x72614b,0xffcc80],"Moss sanctuary":[0x3e6b58,0x9cdbb8],"Sealed reliquary":[0x5b526e,0xc9acf0]};
 const prop=(w,h,d,x,y,z,color,glow=false)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),glow?new T.MeshBasicMaterial({color}):new T.MeshStandardMaterial({color,roughness:.9}));o.position.set(x,y,z);this.root.add(o);return o;};
 const torch=(x,z,color,phase,lit=true)=>{prop(.13,.7,.13,x,2.65,z,0x4a3525);prop(.3,.18,.3,x,2.95,z,0x373e36);const flame=prop(.18,.38,.18,x,3.2,z,color,true);const core=prop(.09,.24,.1,x,3.19,z,0xffe6a0,true);const lamp=new T.PointLight(color,18,12,1.6);lamp.position.set(x,3.3,z);if(lit)this.root.add(lamp);this.torches.push({flame,core,lamp,phase});};
 for(const [i,r]of this.rooms.entries()){if(i===this.rooms.length-1&&floorNumber<3)r.style=floorNumber===1?'Cellblock':'Ember forge';const [stone,light]=palettes[r.style];
 for(const dx of [-3.65,3.65])for(const dz of [-3.65,3.65]){prop(.6,3.8,.6,r.x+.5+dx,2.9,r.z+.5+dz,stone);this.blockers.push(new T.Box3(new T.Vector3(r.x+.5+dx-.3,1,r.z+.5+dz-.3),new T.Vector3(r.x+.5+dx+.3,4.8,r.z+.5+dz+.3)));}
 torch(r.x-2.7,r.z-3.3,light,i);torch(r.x+3.3,r.z+3.3,light,i+2,false);
 for(const side of [-1,1])for(let k=-2;k<=2;k++){if(r.style==='Cellblock')prop(.10,2.5,.10,r.x+.5+side*4.05,2.3,r.z+.5+k*.6,0x819086);if(r.style==='Overgrown cistern')prop(.14,1.2+(k+2)*.18,.45,r.x+.5+side*4.1,3.9,r.z+.5+k,0x4c7940);if(r.style==='Ember forge')prop(.35,.02,.35,r.x+.5+side*3,1.015,r.z+.5+k,0xd69d52,true);}
 if(i===0){for(const dx of [-2,2])prop(.5,.4,.5,r.x+.5+dx,1.2,r.z+2.5,0x766244);}
 
 }
 for(const [i,l]of this.links.entries()){const a=this.rooms[l.a],b=this.rooms[l.b];if(!l.secret)torch((a.x+b.x)/2+.5,(a.z+b.z)/2+.5,0xffbd70,i+4,i%2===0);
 else{const dx=Math.sign(b.x-a.x),dz=Math.sign(b.z-a.z),x=a.x+.5+dx*5.35,z=a.z+.5+dz*5.35,gate=prop(dx?.28:3,4,dz?.28:3,x,3,z,0x656c5c);gate.material.map=this.textures[1];gate.material.needsUpdate=true;const box=new T.Box3().setFromObject(gate);this.blockers.push(box);const clue=new T.Group();this.root.add(clue);for(let j=0;j<3;j++){const shard=prop(dx?.04:.12,.08,dz?.04:.12,x-dx*.16+(dz?(j-1)*.1:0),2.25+j*.13,z-dz*.16+(dx?(j-1)*.1:0),0xa49362,true);clue.attach(shard);}this.secrets.push({link:l,gate,box,clue,opened:false,position:new T.Vector3(x,2.65,z)});}}
 for(const [i,room]of this.rooms.entries()){if(room.kind==='main')continue;const shrine=room.kind==='shrine',x=room.x+2.2,z=room.z+2.2;
 const mesh=prop(shrine?.7:.95,shrine?1.25:.8,shrine?.7:.8,x,shrine?1.625:1.4,z,shrine?0x5a9680:room.kind==='secret'?0x7a5f91:0xa27843);
 const lid=prop(shrine?.45:1.02,shrine?.3:.14,shrine?.45:.87,x,shrine?2.4:1.88,z,shrine?0x9cdbb8:room.kind==='secret'?0xd4b2ee:0xe0c07c,shrine);prop(.16,.18,.05,x,1.7,z+.43,0xf2dca0,true);
 this.treasures.push({id:i,room:i,kind:room.kind,mesh,lid,claimed:false});}
 const last=this.rooms.at(-1);this.exit=prop(1.6,2.6,.25,last.x+.5,2.3,last.z+3,0x4a4b40,true);prop(2,.25,.5,last.x+.5,3.7,last.z+3,0x9b8a62);
 this.cacheRoom=1;this.cacheClaimed=false;const c=this.rooms[1];this.cache=prop(.8,.7,.7,c.x+2.7,1.35,c.z+2.7,0xac8050);this.cacheLid=prop(.87,.15,.77,c.x+2.7,1.78,c.z+2.7,0xd3b679);prop(.15,.22,.05,c.x+2.7,1.6,c.z+3.08,0xf1dd98,true);
 const spawns=this.rooms.flatMap((r,i)=>i===0||r.kind==='shrine'||r.kind==='secret'?[]:[[i,r.x+.5,r.z+.5,i===this.rooms.length-1?(floorNumber===3?2:1):i%2]]);
 this.combat=new Hunt(scene,state,{spawns,statsFor:type=>{const m=MONSTERS[type],scale=1+(floorNumber-1)*.1;return {...m,hp:Math.round(m.hp*this.rules.health*scale),damage:Math.round(m.damage*this.rules.damage),xp:Math.round(m.xp*this.rules.reward),value:Math.round(m.value*this.rules.reward)};},active:()=>true,respawn:false,boundsFor:e=>[e.x-3.1,e.x+3.1,e.z-3.1,e.z+3.1],canAct:(e,p)=>this.roomAt(p)>=0&&this.roomAt(p)===this.roomAt(e.root.position)});
 }
 secretAvailable(p){return this.secrets.find(s=>!s.opened&&p.distanceTo(s.position)<2.6);}
 revealSecret(s){if(!s||s.opened)return false;s.opened=true;s.link.opened=true;s.gate.visible=false;s.clue.visible=false;const n=this.blockers.indexOf(s.box);if(n>=0)this.blockers.splice(n,1);return true;}
 treasureAvailable(p){return this.treasures.find(t=>!t.claimed&&p.distanceTo(new T.Vector3(t.mesh.position.x,2.65,t.mesh.position.z))<2&&!this.combat.enemies.some(e=>!e.dead&&this.roomAt(e.root.position)===t.room));}
 claimTreasure(t){if(t.claimed)return;t.claimed=true;t.lid.rotation.x=-.7;t.mesh.material.color.setHex(0x4e4b42);if(t.kind==='shrine')t.lid.material.color.setHex(0x405b4e);}
 passages(index){return this.links.filter(l=>(!l.secret||l.opened)&&(l.a===index||l.b===index)).map(l=>l.a===index?l.b:l.a);}
 roomAt(p){return this.rooms.findIndex(r=>Math.abs(p.x-r.x-.5)<4.5&&Math.abs(p.z-r.z-.5)<4.5);}
 solid(x,y,z){return y<1||y>5||(!this.floor.has(Math.floor(x)+','+Math.floor(z))&&y<7);}
 obstructed(ray,distance){return this.blocked(ray,distance);}
 blocked(ray,distance){for(let d=.1;d<distance;d+=.12){const p=ray.at(d,new T.Vector3());if(this.solid(p.x,p.y,p.z)||this.blockers.some(b=>b.containsPoint(p)))return true;}return false;}
 cacheAvailable(p){return !this.cacheClaimed&&p.distanceTo(new T.Vector3(this.cache.position.x,2.65,this.cache.position.z))<2&&!this.combat.enemies.some(e=>!e.dead&&this.roomAt(e.root.position)===this.cacheRoom);}
 claimCache(){this.cacheClaimed=true;this.cacheLid.rotation.x=-.7;this.cache.material.color.setHex(0x5b4a36);}
 update(position,dt=0,reduced=false){this.time+=dt;const room=this.roomAt(position);if(room>=0)this.visited.add(room);this.cleared=this.combat.enemies.every(e=>e.dead||!this.rooms[this.roomAt(e.root.position)]?.critical);this.atExit=position.distanceTo(new T.Vector3(this.exit.position.x,2.65,this.exit.position.z))<1.9;this.exit.material.color.setHex(this.cleared?0xe0c578:0x4a4b40);for(const t of this.torches){const pulse=reduced?1:1+Math.sin(this.time*8+t.phase)*.08+Math.sin(this.time*17+t.phase)*.035;t.lamp.intensity=18*pulse;t.flame.scale.set(1,pulse,1);}}
 dispose(){this.combat.dispose();this.root.removeFromParent();const gs=new Set(),ms=new Set();this.root.traverse(o=>{if(o.geometry)gs.add(o.geometry);if(o.material)ms.add(o.material);if(o.isInstancedMesh)o.dispose();});gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());this.textures.forEach(t=>t.dispose());}
}
