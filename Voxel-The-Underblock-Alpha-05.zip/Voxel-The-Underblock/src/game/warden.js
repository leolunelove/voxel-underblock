import * as T from '../../vendor/three.module.js';
// Presentation is independent of damage and reward rules.
export function dressWarden(root,arms){
 const steel=new T.MeshStandardMaterial({color:0x343845,metalness:.65,roughness:.4}),gold=new T.MeshStandardMaterial({color:0xbb9560,metalness:.7,roughness:.35}),dark=new T.MeshLambertMaterial({color:0x171e28}),glow=new T.MeshBasicMaterial({color:0xffcb79});
 const box=(parent,w,h,d,x,y,z,mat)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),mat);o.position.set(x,y,z);parent.add(o);return o;};
 box(root,.96,.7,.76,0,.94,0,steel);box(root,.12,.65,.05,0,.98,.41,gold);box(root,.56,.12,.06,0,1.55,.32,dark);box(root,.52,.045,.07,0,1.57,.36,glow);box(root,.8,.18,.7,0,1.8,0,steel);
 for(const side of [-1,1]){box(root,.42,.28,.85,side*.58,1.23,0,steel);box(root,.45,.07,.9,side*.58,1.38,0,gold);box(root,.33,.38,.4,side*.25,.22,.05,steel);box(root,.15,.34,.18,side*.35,1.97,0,gold);}
 box(root,.14,.46,.18,0,2.03,0,gold);box(root,.55,.62,.12,0,.58,-.43,dark);
 const hammer=new T.Group();hammer.name='warden-hammer';arms[1].add(hammer);box(hammer,.12,1.15,.12,0,-.35,.05,dark);box(hammer,.62,.42,.55,0,-.9,.05,steel);box(hammer,.67,.12,.58,0,-.9,.05,gold);
 const shock=new T.Mesh(new T.RingGeometry(.92,1,40),new T.MeshBasicMaterial({color:0xffce83,side:T.DoubleSide,transparent:true,opacity:0,depthWrite:false}));shock.rotation.x=-Math.PI/2;shock.position.y=.035;root.add(shock);shock.userData.effect=true;
 return {shock,gold,steel};
}
export function animateWarden(e,reduced){const v=e.warden;if(!v)return;const brain=e.brain,a=brain?.attack,charge=brain?.progress??0;
 if(e.dead){v.shock.visible=false;return;}
 if(!reduced){e.arms[0].rotation.z=0;e.arms[1].rotation.z=0;
 if(e.windup>0){if(a?.id==='sweep'){e.arms[1].rotation.z=-charge*1.65;e.arms[1].rotation.x=-charge*.6;e.root.rotation.x=-charge*.06;}else if(a?.id==='charge'){e.arms[0].rotation.x=-.8;e.arms[1].rotation.x=.2;e.root.rotation.x=charge*.35;}else{e.arms[1].rotation.x=-charge*2.65;e.arms[0].rotation.x=-charge*.8;e.root.rotation.x=-charge*.12;}}
 else if(e.lunge>0){if(a?.id==='sweep')e.arms[1].rotation.z=1.4;else e.arms[1].rotation.x=.9;e.root.rotation.x=a?.id==='charge'?.45:.22;}
 else{e.arms[1].rotation.x=brain?.state==='recovery'?.45:.08;}
 const recoil=Math.max(0,Math.min(1,e.hit/.27))**2;e.body.rotation.z=recoil*.09;e.root.rotation.x-=recoil*.1;}
 v.steel.emissive.setHex(e.hit>0?0x6e3421:brain?.enraged?0x451b0a:0);v.steel.emissiveIntensity=e.hit>0?e.hit/.27:brain?.enraged?.28:0;
 v.shock.visible=(e.shockTime??0)>0&&a?.id==='slam';v.shock.scale.setScalar(reduced?3.15:3.15*(1-(e.shockTime??0)/.45));v.shock.material.opacity=(e.shockTime??0)/.45*.8;
}
