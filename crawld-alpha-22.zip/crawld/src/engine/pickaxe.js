import {BOW_ROTATION} from './bow-motion.js?v=22';
import {SWORDS,BOWS} from '../game/weapons.js?v=22';
import * as T from '../../vendor/three.module.js?v=22';
// A thin pixel-built item, with a diagonal wooden shaft and a stepped silhouette.
const PALETTES=[[0x566161,0xb9c3bc,0xe2e6da],[0x4c5657,0xc9d4cc,0xf1f3e8],[0x20594c,0x54c7a7,0xa0f1cf],[0x364e5f,0x92b8cc,0xd9edf2],[0x765a24,0xd4ac45,0xffdf83],[0x713e31,0xe18a59,0xffc388]];
export function toolArtwork(tier,axe=false){
 const grid=Array.from({length:16},()=>Array(16).fill('.'));
 const put=(x,y,c)=>{if(x>=0&&x<16&&y>=0&&y<16)grid[y][x]=c;};
 for(let i=0;i<12;i++){const x=2+i,y=14-i;put(x,y,'h');put(x+1,y,'b');if(i%3===0)put(x,y,'H');}
 put(2,15,'b');put(13,2,'b');put(14,3,'b');
 const rows=axe?[[2,8,10],[3,7,12],[4,6,12],[5,6,11],[6,7,10]]:[[2,5,8],[3,2,9],[4,7,10],[5,9,11],[6,11,11],[7,11,11],[8,11,11]];
 const cells=[];for(const [y,a,b]of rows)for(let x=a;x<=b;x++)cells.push([x,y]);
 for(const [x,y]of cells)for(const [dx,dy]of [[-1,0],[1,0],[0,-1],[0,1]])put(x+dx,y+dy,'O');
 for(const [x,y]of cells)put(x,y,y===2||x===rows.find(r=>r[0]===y)[1]?'S':'M');
 const palette=PALETTES[Math.min(5,tier)],colors={O:palette[0],M:palette[1],S:palette[2],b:0x3b220e,h:0x593817,H:0x67401e};
 return {grid,colors};
}
function pixelTool(tier,axe=false){
 const {grid,colors}=toolArtwork(tier,axe);
 const unit=new T.BoxGeometry(.066,.066,.052),positions=[],normals=[],vertexColors=[];
 // Non-indexed boxes form one draw call; square pixels keep the tool's silhouette crisp.
 const geo=unit.toNonIndexed(),v=geo.attributes.position,norm=geo.attributes.normal;
 for(let y=0;y<16;y++)for(let x=0;x<16;x++){const ch=grid[y][x];if(ch==='.')continue;const color=new T.Color(colors[ch]);for(let i=0;i<v.count;i++){positions.push(v.getX(i)+(x-7.5)*.066,v.getY(i)+(7.5-y)*.066,v.getZ(i));normals.push(norm.getX(i),norm.getY(i),norm.getZ(i));const shade=norm.getZ(i)===0?.76:1;vertexColors.push(color.r*shade,color.g*shade,color.b*shade);}}
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(normals,3));geometry.setAttribute('color',new T.Float32BufferAttribute(vertexColors,3));geometry.computeBoundingSphere();unit.dispose();geo.dispose();
 const root=new T.Group();root.add(new T.Mesh(geometry,new T.MeshLambertMaterial({vertexColors:true})));return root;
}
export function toolIcon(tier,kind='pick'){const {grid,colors}=toolArtwork(kind==='axe'?([0,1,2,4][tier]??0):tier,kind==='axe'),canvas=document.createElement('canvas');canvas.width=canvas.height=16;const ctx=canvas.getContext('2d');for(let y=0;y<16;y++)for(let x=0;x<16;x++)if(grid[y][x]!=='.'){ctx.fillStyle='#'+colors[grid[y][x]].toString(16).padStart(6,'0');ctx.fillRect(x,y,1,1);}return canvas.toDataURL();}
export function createPickaxe(tier){
 const root=new T.Group(),palette=PALETTES[Math.min(5,tier)];
 const wood=new T.MeshLambertMaterial({color:0x67401e}),grip=new T.MeshLambertMaterial({color:0x382719}),metal=new T.MeshLambertMaterial({color:palette[1]}),edge=new T.MeshLambertMaterial({color:palette[0]}),shine=new T.MeshLambertMaterial({color:palette[2]});
 const box=(size,position,material,angle=0)=>{const mesh=new T.Mesh(new T.BoxGeometry(...size),material);mesh.position.set(...position);mesh.rotation.z=angle;root.add(mesh);return mesh;};
 // A solid square shaft, with a real socket around its upper end.
 const bottom=new T.Vector3(-.32,-.49,.07),top=new T.Vector3(.19,.30,.02),mid=bottom.clone().add(top).multiplyScalar(.5),shaft=box([.085,bottom.distanceTo(top),.085],mid.toArray(),wood);
 shaft.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),top.clone().sub(bottom).normalize());
 for(let i=0;i<4;i++){const p=bottom.clone().lerp(top,.10+i*.075),band=box([.098,.035,.098],p.toArray(),grip);band.quaternion.copy(shaft.quaternion);}
 box([.17,.20,.17],[.15,.27,.01],edge,-.12);
 box([.19,.055,.19],[.15,.35,.01],shine,-.12);
 // The working point reaches away from the player. Stepped sections taper
 // in all three dimensions instead of extruding a flat item silhouette.
 for(const [size,pos] of [ [[.22,.13,.18],[.015,.30,-.04]], [[.18,.105,.15],[-.16,.285,-.12]], [[.13,.075,.10],[-.30,.255,-.21]], [[.065,.045,.06],[-.385,.23,-.27]] ])box(size,pos,metal);
 box([.20,.11,.17],[.30,.235,.065],metal,-.32);
 box([.11,.14,.13],[.405,.15,.10],metal,-.27);
 box([.065,.13,.08],[.44,.045,.12],edge,-.12);
 return root;
}
export function createAxe(tier){
 const root=new T.Group(),palette=PALETTES[[0,1,2,4][tier]??0];
 const wood=new T.MeshLambertMaterial({color:0x67401e}),grip=new T.MeshLambertMaterial({color:0x382719}),metal=new T.MeshLambertMaterial({color:palette[1]}),dark=new T.MeshLambertMaterial({color:palette[0]}),edge=new T.MeshLambertMaterial({color:palette[2]});
 const box=(size,p,mat)=>{const m=new T.Mesh(new T.BoxGeometry(...size),mat);m.position.set(...p);root.add(m);return m;};
 const bottom=new T.Vector3(-.28,-.49,.08),top=new T.Vector3(.14,.34,.01),direction=top.clone().sub(bottom),shaft=box([.09,direction.length(),.09],bottom.clone().lerp(top,.5).toArray(),wood);shaft.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),direction.normalize());
 for(let i=0;i<4;i++){const b=box([.105,.035,.105],bottom.clone().lerp(top,.10+i*.075).toArray(),grip);b.quaternion.copy(shaft.quaternion);}
 box([.18,.24,.19],[.12,.25,.01],dark);box([.18,.07,.19],[.27,.25,.02],metal);
 box([.22,.29,.18],[-.04,.26,-.045],metal);box([.14,.36,.13],[-.20,.25,-.13],metal);
 box([.075,.39,.075],[-.30,.245,-.20],edge);box([.045,.33,.045],[-.355,.245,-.24],edge);
 return root;
}
export {createSword,createBow} from './weapon-look.js?v=22';
export function bowPose(draw,aspect,recoil=0){const pull=Math.max(0,Math.min(1,draw));return {position:[.02-pull*.12+recoil*.008,-.13-recoil*.012,-1.95-pull*.035+recoil*.06],rotation:[...BOW_ROTATION]};}
export function swingPose(phase){
 // A deliberate lift, accelerating downstroke, two-frame contact, then a
 // short rebound. Recovery occupies most of the cycle so holding feels calm.
 const keys=[[0,0,0,0,0,0,0],[.16,.01,.13,.035,.08,-.04,.025],[.30,-.10,-.015,-.20,-.36,.05,-.04],[.34,-.10,-.015,-.20,-.36,.05,-.04],[.48,-.035,.09,.025,.045,-.025,.02],[.76,0,0,0,0,0,0],[1,0,0,0,0,0,0]];
 for(let i=1;i<keys.length;i++){const a=keys[i-1],b=keys[i];if(phase<=b[0]){if(phase===b[0])return b.slice(1);let t=Math.max(0,(phase-a[0])/(b[0]-a[0]));t=i===2?t*t:t*t*(3-2*t);return a.slice(1).map((v,j)=>v+(b[j+1]-v)*t);}}
 return [0,0,0,0,0,0];
}

export const TOOL_SCALE=1.08;
export const BOW_SCALE=TOOL_SCALE*.78;
export const TOOL_DEPTH=1.90;
export const CONTACT_TIP=new T.Vector3(-.4175,.23,-.30);
export const AXE_TIP=new T.Vector3(-.3775,.245,-.2625);
export const SWORD_TIP=new T.Vector3(0,.715,0);
export function swordSwingPose(phase){
 const keys=[[0,0,0,0,0,0,0],[.18,.035,.10,.05,.11,-.08,.20],[.30,-.08,-.06,-.23,-.44,.12,-.24],[.34,-.08,-.06,-.23,-.44,.12,-.24],[.50,.015,.055,.04,.08,-.025,.08],[.82,0,0,0,0,0,0],[1,0,0,0,0,0,0]];
 for(let i=1;i<keys.length;i++){const a=keys[i-1],b=keys[i];if(phase<=b[0]){let t=Math.max(0,(phase-a[0])/(b[0]-a[0]));t=i===2?t*t:t*t*(3-2*t);return a.slice(1).map((v,j)=>v+(b[j+1]-v)*t);}}return [0,0,0,0,0,0];
}
export function heldPose(phase,aspect,motion=1,kind='pick',draw=0,recoil=0){
 if(kind==='bow')return bowPose(draw,aspect,recoil);
 const p=kind==='sword'?swordSwingPose(phase):swingPose(phase),halfWidth=Math.tan(24*Math.PI/180)*TOOL_DEPTH*aspect,x=Math.min(.42,halfWidth*.44),distance=phase<.30?.30-phase:Math.max(0,phase-.34),t=Math.max(0,1-distance/.14),contact=t*t*(3-2*t);
 const rotation=[-.15+p[3]*motion*(kind==='axe'?1.14:1),-.72+p[4]*motion,-.05+p[5]*motion];
 if(kind==='sword'){rotation[0]=-.35+p[3]*motion*1.4;rotation[1]=-.25+p[4]*motion;rotation[2]=-.25+p[5]*motion;}
 const position=[x*(kind==='pick'?.72:1)+p[0]*motion+(.45-x)*contact*motion-(kind==='axe'?.20*contact*motion:0),-.40+p[1]*motion+(kind==='axe'?.09*contact*motion:0),-TOOL_DEPTH+p[2]*motion];
 position[0]=Math.min(position[0],halfWidth*.30);if(kind==='sword')position[2]-=.16*contact*motion;
 const tip=(kind==='sword'?SWORD_TIP:kind==='pick'?CONTACT_TIP:AXE_TIP).clone().multiplyScalar(TOOL_SCALE).applyEuler(new T.Euler(...rotation));position[0]+=(-tip.x-position[0])*contact*motion;position[1]+=(-tip.y-position[1])*contact*motion;
 return {position,rotation};
}
// Solve the viewmodel tip onto the aimed surface's screen position, independent
// of camera yaw/pitch. This does not rotate, slow, or lock the gameplay camera.
export function contactPivot(point,gameCamera,viewCamera,rotation,scale=TOOL_SCALE,tipPoint=CONTACT_TIP){
 const ndc=point.clone().project(gameCamera),depth=TOOL_DEPTH;
 const target=new T.Vector3(ndc.x,ndc.y,.5).unproject(viewCamera);
 target.multiplyScalar(-depth/target.z);
 const tip=tipPoint.clone().multiplyScalar(scale).applyEuler(rotation);
 return target.sub(tip);
}
