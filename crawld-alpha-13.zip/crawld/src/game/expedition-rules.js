export const FLOORS=3;
export const level=xp=>Math.min(20,1+Math.floor(Math.sqrt(Math.max(0,xp)/30)));
export function freshProfile(){return {money:0,xp:0,archeryXP:0,dungeonXP:0,kills:0,completions:0,sword:0,bow:0,relicSword:false,relicBow:false};}
export function loadProfile(raw){const p=freshProfile();if(!raw||typeof raw!=='object')return p;for(const k of ['money','xp','archeryXP','dungeonXP','kills','completions'])if(Number.isSafeInteger(raw[k])&&raw[k]>=0&&raw[k]<=1e9)p[k]=raw[k];for(const k of ['sword','bow'])if(Number.isInteger(raw[k])&&raw[k]>=0&&raw[k]<=3&&level(k==='sword'?p.xp:p.archeryXP)>=[1,2,4,7][raw[k]])p[k]=raw[k];for(const k of ['relicSword','relicBow'])p[k]=raw[k]===true;return p;}
export function newRun(difficulty=0){return {floor:1,difficulty:Math.max(0,Math.min(2,Math.trunc(difficulty)||0)),potions:2,loot:0,edge:1,secretsFound:0,treasures:[],caches:[],completed:false,ended:false};}
export function heal(run,actor){if(run.ended||run.potions<=0||actor.hp<=0||actor.hp>=100)return 0;const n=Math.min(40,100-actor.hp);actor.hp+=n;run.potions--;return n;}
export function claimCache(run,actor,room){const key=run.floor+':'+room;if(run.ended||actor.hp<=0||run.caches.includes(key))return false;run.caches.push(key);run.potions++;actor.loot+=25*(run.difficulty+1);return true;}
export function descend(run,cleared,atExit){if(run.ended||run.floor>=FLOORS||!cleared||!atExit)return false;run.floor++;run.edge=1;return true;}
export function extract(run,actor,profile,cleared,atExit){if(run.ended||actor.hp<=0||run.floor!==FLOORS||!cleared||!atExit)return null;const reward=[1,2,3.5][run.difficulty],bonus=[100,250,550][run.difficulty],xp=Math.round(220*reward),money=actor.loot+bonus;for(const kind of run.relics??[])profile[kind==='sword'?'relicSword':'relicBow']=true;profile.money+=money;profile.dungeonXP+=xp;profile.completions++;actor.loot=0;run.completed=true;run.ended=true;return {money,xp};}
export function forfeit(run,actor){if(run.ended)return 0;const lost=actor.loot;actor.loot=0;for(const kind of run.relics??[])actor[kind==='sword'?'relicSword':'relicBow']=false;run.ended=true;return lost;}
// Combat timing is simulation-owned; viewmodel animation cannot award hits.
export class MeleeCycle{
 constructor(){this.reset();}
 get phase(){return this.age/.50;}
 get cutting(){return this.active&&!this.connected&&this.age>=.145&&this.age<=.22;}
 reset(){this.age=0;this.active=false;this.hit=false;this.stroke=0;this.freeze=0;this.connected=false;this.swish=false;}
 contact(seconds=.045){this.connected=true;this.freeze=Math.max(0,seconds);}
 step(dt,held){this.swish=false;if(this.freeze>0){this.freeze=Math.max(0,this.freeze-dt);return false;}
 if(!this.active){if(!held)return false;this.active=true;this.age=0;this.hit=false;this.connected=false;this.stroke++;}
 const before=this.age;this.age+=Math.max(0,Math.min(.05,dt));this.swish=before<.09&&this.age>=.09;
 const impact=!this.hit&&before<.15&&this.age>=.15;if(impact)this.hit=true;
 if(this.age>=.5){this.age=held?this.age-.5:0;this.active=held;this.hit=false;this.connected=false;if(held)this.stroke++;}return impact;
 }
}
export function chooseMelee(enemies,position,direction,blocked){let best=null,score=Infinity;for(const e of enemies){if(e.dead)continue;const dx=e.root.position.x-position.x,dz=e.root.position.z-position.z,dy=e.root.position.y+1.2-position.y,d=Math.hypot(dx,dz),dot=d>0?(dx*direction.x+dz*direction.z)/d:1;if(d>3.05||Math.abs(dy)>1.9||dot<.82||blocked(e))continue;const rank=d+(1-dot)*4;if(rank<score){best=e;score=rank;}}return best;}

export function claimDiscovery(run,actor,id,kind){const key=run.floor+':'+id;if(run.ended||actor.hp<=0||run.treasures.includes(key))return null;
 if(kind==='shrine'){if(actor.hp>=100)return null;const healing=Math.min(35,100-actor.hp);actor.hp+=healing;run.treasures.push(key);return {coins:0,healing,tonics:0};}
 if(!['treasure','secret'].includes(kind))return null;const coins=Math.round((kind==='secret'?140:75)*run.floor*[1,2,3.5][run.difficulty]);actor.loot+=coins;run.treasures.push(key);if(kind==='secret'){run.potions++;run.edge=1.2;}return {coins,healing:0,tonics:kind==='secret'?1:0,edge:run.edge};}
