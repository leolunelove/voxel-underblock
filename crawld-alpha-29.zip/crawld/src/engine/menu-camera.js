// A slow dolly through the first three chambers. UI never follows the camera.
export function menuPose(part,time){
 const a=part.d.rooms[0],b=part.d.rooms[2],travel=.5+.5*Math.sin(time*.045-.8);
 return {x:a.x+.5+Math.sin(time*.12)*.32,y:part.base+2.85+Math.sin(time*.19)*.025,z:(a.z+2.6)*(1-travel)+(b.z+1)*travel,pitch:-.035,yaw:Math.sin(time*.09)*.025};
}
