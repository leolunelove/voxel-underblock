import * as T from '../../vendor/three.module.js?v=29';
// Face-by-face patina is baked into a single mesh per animated part.
function forge(){
 const positions=[],normals=[],colors=[];let seed=31;
 const face=(vertices,color)=>{const [a,b,c]=vertices.map(v=>new T.Vector3(...v)),normal=b.clone().sub(a).cross(c.clone().sub(a)).normalize(),shade=new T.Color(color);for(const v of vertices){positions.push(...v);normals.push(normal.x,normal.y,normal.z);colors.push(shade.r,shade.g,shade.b);}};
 return {face,box(size,pos,color,angle=0){const g=new T.BoxGeometry(...size,2,Math.max(1,Math.ceil(size[1]*24)),1).toNonIndexed();g.rotateX(angle);g.translate(...pos);const p=g.attributes.position,n=g.attributes.normal,c=new T.Color(color);for(let i=0;i<p.count;i++){if(i%3===0)seed=(seed*1664525+1013904223)>>>0;const shade=.78+(seed%100)/450;positions.push(p.getX(i),p.getY(i),p.getZ(i));normals.push(n.getX(i),n.getY(i),n.getZ(i));colors.push(c.r*shade,c.g*shade,c.b*shade);}g.dispose();},finish(parent,name,metal=false){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('normal',new T.Float32BufferAttribute(normals,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.computeBoundingSphere();const m=new T.Mesh(g,metal?new T.MeshStandardMaterial({vertexColors:true,metalness:.48,roughness:.58}):new T.MeshLambertMaterial({vertexColors:true}));m.name=name;parent.add(m);return m;}};
}
const STEEL=[0x626b65,0x8c9997,0x397764,0xa08c55],EDGE=[0xa5aaa0,0xc2c7b7,0x8ebca4,0xc8b47b],TRIM=[0x756046,0x657476,0x405b43,0x9e7847];
export function createSword(tier=0,rare=false){
 const root=new T.Group(),hilt=forge(),blade=forge(),wide=tier>=2?.165:.145,metal=STEEL[tier],edge=EDGE[tier],trim=TRIM[tier];
 // Wrapped leather sits between a shaped guard and a weighted, faceted pommel.
 hilt.box([.082,.34,.095],[0,-.30,0],0x2b2520);
 for(let i=0;i<7;i++)hilt.box([.096,.018,.108],[0,-.44+i*.043,0],i%2?0x51402e:0x362d25);
 hilt.box([.12,.055,.125],[0,-.46,0],trim);hilt.box([.11,.04,.13],[0,-.13,0],trim);
 const ring=[[-.077,-.515,0],[0,-.515,-.06],[.077,-.515,0],[0,-.515,.06]];
 for(let i=0;i<4;i++){hilt.face([[0,-.455,0],ring[i],ring[(i+1)%4]],i%2?trim:metal);hilt.face([[0,-.575,0],ring[(i+1)%4],ring[i]],i%2?metal:trim);}
 hilt.box([.29,.075,.145],[0,-.095,0],trim);
 for(const side of [-1,1])for(let i=0;i<3;i++){
  hilt.box([.065,.06,.14-i*.015],[side*(.145+i*.045),-.085+i*.018,0],i===2?metal:trim);
  hilt.box([.045,.012,.15-i*.015],[side*(.145+i*.045),-.052+i*.018,0],edge);
 }
 hilt.box([.07,.08,.15],[0,-.06,0],metal);hilt.box([.025,.025,.156],[0,-.06,0],rare?0xc6a36e:trim);
 hilt.finish(root,'bound-leather-hilt');
 // A solid taper with sharpened bevels and a recessed central fuller on both faces.
 const section=[[-1,0],[-.68,-1],[-.18,-1],[-.13,-.7],[.13,-.7],[.18,-1],[.68,-1],[1,0],[.68,1],[.18,1],[.13,.7],[-.13,.7],[-.18,1],[-.68,1]];
 const rings=[[-.06,1,.035],[.08,1,.035],[.43,.86,.031],[.59,.66,.025],[.66,.34,.014],[.715,.015,.001]].map(([y,w,z])=>section.map(([x,depth])=>[x*wide*.5*w,y,depth*z]));
 for(let j=0;j<rings.length-1;j++)for(let i=0;i<section.length;i++){
  const next=(i+1)%section.length,bevel=Math.max(Math.abs(section[i][0]),Math.abs(section[next][0]))>.8,groove=Math.abs(section[i][0])<=.18&&Math.abs(section[next][0])<=.18;
  const color=bevel?edge:groove?0x35423d:metal;
  blade.face([rings[j][i],rings[j+1][i],rings[j+1][next]],color);blade.face([rings[j][i],rings[j+1][next],rings[j][next]],color);
 }
 for(let i=0;i<section.length;i++){const n=(i+1)%section.length;blade.face([[0,-.06,0],rings[0][i],rings[0][n]],metal);blade.face([[0,.715,0],rings.at(-1)[n],rings.at(-1)[i]],edge);}
 for(const side of [-1,1]){
  for(let i=0;i<6;i++){const y=.025+i*.078,x=(i%2?1:-1)*wide*.25;blade.box([.018,.003,.0015],[x,y,side*(.035-i*.0006)],i%3===0&&tier===0?0x754e35:edge);}
  if(rare||tier>=2)for(let i=0;i<(rare?4:3);i++)blade.box([.018,.011,.002],[0,.08+i*.075,side*.025],rare?0xc6a36e:edge);
 }
 blade.finish(root,'weathered-blade',true);return root;
}
export function createBow(tier=0,rare=false){const root=new T.Group(),wood=[0x514332,0x596665,0x355c49,0x625034][tier],trim=TRIM[tier],edge=EDGE[tier],f=forge();
 f.box([.13,.24,.17],[.31,0,-.20],0x302920);
 for(let i=0;i<6;i++)f.box([.145,.019,.18],[.31,-.10+i*.04,-.20],i%2?0x5c4934:0x44372b);
 for(const side of [-1,1]){f.box([.15,.035,.19],[.31,side*.13,-.20],trim);const limb=new T.Group();limb.name=side>0?'upper-limb':'lower-limb';root.add(limb);const l=forge();for(const [y,z,a]of [[.20,-.16,-.30],[.39,-.075,-.50]]){const angle=side*a;l.box([.085+(tier===3?.025:0),.25,.12],[.28,side*y,z],wood,angle);l.box([.018,.22,.125],[.245,side*y,z],trim,angle);
 for(let i=0;i<3;i++)l.box([.036,.035,.135],[.28,side*(y-.07+i*.065),z],i===1?trim:wood,angle);
 l.box([.012,.14,.004],[.30,side*y,z+.063],edge,angle);}
 l.box([.11,.08,.11],[.28,side*.49,-.015],trim);l.box([.055,.018,.12],[.28,side*.505,-.015],edge);l.box([.025,.04,.13],[.28,side*.43,-.04],edge);l.finish(limb,'laminated-limb');}
 if(rare)for(const side of [-1,1])f.box([.15,.02,.195],[.31,side*.08,-.20],0xc6a36e);f.finish(root,'leather-grip');
 const g=new T.BufferGeometry().setFromPoints([new T.Vector3(.28,-.50,-.015),new T.Vector3(.20,0,.02),new T.Vector3(.28,.50,-.015)]),string=new T.Line(g,new T.LineBasicMaterial({color:0xbab39a}));string.name='bowstring';root.add(string);
 const arrow=new T.Group();arrow.name='loaded-arrow';const a=forge();a.box([.026,.026,1.4],[0,0,-.64],0x7a6749);a.box([.018,.008,1.1],[0,.014,-.64],0xaa9870);a.box([.055,.018,.10],[0,0,.025],0xb4b29c);a.box([.018,.055,.10],[0,0,.025],0x6f7e72);a.box([.065,.065,.10],[0,0,-1.39],0x686f69);a.finish(arrow,'worn-arrow');arrow.position.x=.20;root.add(arrow);return root;
}
