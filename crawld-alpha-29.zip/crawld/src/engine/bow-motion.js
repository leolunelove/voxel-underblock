import * as T from '../../vendor/three.module.js?v=29';
export const BOW_ROTATION=[.025,.42,-.035];
export const ARROW_DIRECTION=new T.Vector3(0,0,-1);
export function nockedArrowDirection(position,rotation,scale,nock){
 const q=new T.Quaternion().setFromEuler(new T.Euler(...rotation)),origin=new T.Vector3(...nock).multiplyScalar(scale).applyQuaternion(q).add(new T.Vector3(...position));
 return new T.Vector3(0,0,-14).sub(origin).normalize().applyQuaternion(q.invert());
}
export function bowRig(draw,releaseAge=Infinity,releasedCharge=1,reduced=false,spec={}){
 const d=Math.max(0,Math.min(1,draw)),pull=d*d*(3-2*d),age=Math.max(0,releaseAge),recovery=spec.recovery??.26,releasing=age<recovery;
 const settle=Math.max(0,Math.min(1,(age-.075)/(recovery-.075))),aim=releasing?releasedCharge*releasedCharge*(3-2*releasedCharge)*(1-settle*settle*(3-2*settle)):pull;
 const tension=releasing?releasedCharge*Math.exp(-age*30)*Math.cos(age*105):pull;
 return {pull,aim,tension,nock:[.20,0,.02+.94*tension],bend:tension*(spec.bend??.32),arrowVisible:!releasing||age<.028,arrowLaunch:releasing?Math.min(1,age/.028)*2.8:0,
 follow:reduced?0:releasing?-.035*(spec.impact??1)*Math.sin(Math.min(1,age/.11)*Math.PI)*Math.exp(-age*8):0};
}
export function applyBowRig(tool,rig,pose={position:[0,0,-1.7],rotation:BOW_ROTATION,scale:.8424}){
 const points=tool.getObjectByName('bowstring').geometry.attributes.position;
 for(const [index,side]of [[0,-1],[2,1]]){const y=side*.50,z=-.015,c=Math.cos(side*rig.bend),s=Math.sin(side*rig.bend);points.setXYZ(index,.28,y*c-z*s,y*s+z*c);}
 points.setXYZ(1,...rig.nock);points.needsUpdate=true;
 const flight=nockedArrowDirection(pose.position,pose.rotation,pose.scale,rig.nock),arrow=tool.getObjectByName('loaded-arrow');
 arrow.position.set(...rig.nock).addScaledVector(flight,rig.arrowLaunch);arrow.visible=rig.arrowVisible;arrow.quaternion.setFromUnitVectors(ARROW_DIRECTION,flight);
 for(const [name,side]of [['upper-limb',1],['lower-limb',-1]])tool.getObjectByName(name).rotation.x=side*rig.bend;
}
