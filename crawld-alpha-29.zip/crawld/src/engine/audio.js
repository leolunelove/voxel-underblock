export class Audio{
 constructor(){this.context=null;this.muted=false;this.noise=null;this.variant=0;}
 unlock(){this.context??=new(window.AudioContext||window.webkitAudioContext)();this.context.resume();if(!this.master){this.master=this.context.createGain();this.master.gain.value=this.volume??.75;this.master.connect(this.context.destination);}if(!this.noise){const c=this.context;this.noise=c.createBuffer(1,c.sampleRate,c.sampleRate);const d=this.noise.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;}}
 tone(t,f,duration,volume,type='sine',end=f*.65){const c=this.context,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(end,t+duration);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(volume,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+duration);o.connect(g);g.connect(this.master??c.destination);o.start(t);o.stop(t+duration+.01);o.onended=()=>{o.disconnect();g.disconnect();};}
 grit(t,duration,volume,frequency){const c=this.context,n=c.createBufferSource(),filter=c.createBiquadFilter(),g=c.createGain();n.buffer=this.noise;filter.type='bandpass';filter.frequency.value=frequency;filter.Q.value=.65;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(volume,t+.003);g.gain.exponentialRampToValueAtTime(.0001,t+duration);n.connect(filter);filter.connect(g);g.connect(this.master??c.destination);n.start(t,Math.random()*.6,duration);n.onended=()=>{n.disconnect();filter.disconnect();g.disconnect();};}
 play(kind,type=0,tier=0){
 if(!this.context||this.muted||!this.noise)return;const t=this.context.currentTime;
 if(kind==='footstep'||kind==='land'){
  const weight=Math.max(.3,Math.min(1.5,tier||1)),v=[.94,1.03,.98,1.06][this.variant++%4],landing=kind==='land',gain=weight*(landing?1.55:1);
  this.tone(t,(type===1?92:122)*v,landing?.11:.065,.012*gain,'sine',landing?38:58);
  this.grit(t,type===1?.095:.055,(type===1?.026:.021)*gain,(type===1?1800:type===2?800:1100)*v);
  this.grit(t+.022,.035,.010*gain,type===2?2400:2700*v);
  if(type===0)this.grit(t+.085,.045,.004*gain,650*v);
  if(type===2)this.grit(t+.045,.08,.014*gain,480*v);
  if(landing)this.grit(t+.02,.11,.022*gain,310);return;
 }
 if(kind==='jump'){this.grit(t,.10,.014,530);this.grit(t+.02,.055,.006,1600);return;}
 if(kind==='menu-hover'){this.tone(t,540,.055,.009,'sine',650);this.grit(t,.022,.006,1500);return;}
 if(kind==='menu-click'){this.tone(t,190,.07,.025,'triangle',95);this.grit(t,.025,.025,1100);this.tone(t+.025,690,.12,.012,'sine',520);return;}
 if(kind==='menu-enter'){this.tone(t,110,.24,.035,'triangle',55);this.grit(t,.09,.025,650);[330,440,660].forEach((f,i)=>this.tone(t+.035+i*.045,f,.25,.014,'sine',f*.9));return;}
 if(kind==='monster-tell'){this.grit(t,.16,.025,220);this.tone(t,130,.18,.025,'triangle',95);return;}
 if(kind==='boss-tell'){this.tone(t,78,.32,.045,'sawtooth',55);this.tone(t+.08,155,.23,.018,'triangle',100);return;}
 if(kind==='charge'){this.grit(t,.32,.065,480);this.tone(t,110,.28,.035,'triangle',65);return;}
 if(kind==='boss-slam'){this.tone(t,60,.35,.10,'triangle',26);this.grit(t,.24,.12,250);this.grit(t+.02,.12,.055,1600);return;}
 if(kind==='sword-swish'){const weight=type>0?Math.min(1.9,type):1,pitch=tier>0?tier:1,v=[.94,1.04,.98,1.07][this.variant++%4]*pitch;this.grit(t,.075+weight*.012,.035+weight*.008,1450*v);this.grit(t+.025,.065,.052,3000*v);this.grit(t+.045,.05,.015,4700*v);return;}
 if(kind==='sword-flesh'||kind==='sword-finish'||kind==='sword-armor'){
  const weight=type>0?Math.max(.8,Math.min(1.9,type)):1,pitch=tier>0?tier:1,v=[.95,1.03,.98,1.05][this.variant++%4]*pitch,gain=.8+weight*.2,armor=kind==='sword-armor',finish=kind==='sword-finish';
  // A short edge crack leads the heavier body impact; resonance stays underneath.
  this.grit(t,.016,.18*gain,armor?3500:2150);this.tone(t,145*v,.065,.075*gain,'triangle',49*v);
  this.grit(t+.012,.075,.08*gain,armor?1100:490);this.tone(t+.009,(80-weight*8)*v,.14+weight*.015,.043+weight*.014,'sine',30*v);
  this.grit(t+.026,.035,.026*gain,armor?4300:1400);
  if(armor){this.tone(t+.004,2050*v,.09,.022,'sine',1320*v);this.tone(t+.011,3020*v,.055,.010,'sine',2000*v);}
  if(finish){this.grit(t+.038,.17,.085,285);this.tone(t+.038,88*v,.23,.05,'triangle',26);}
  return;
 }
 if(kind==='bow-tension'){this.tone(t,105+type*75,.10,.012,'triangle',135+type*85);this.grit(t,.05,.012,650+type*300);return;}
 if(kind==='bow-ready'){this.grit(t,.045,.016,950);this.tone(t,155,.07,.009,'triangle',125);return;}
 if(kind==='boss-victory'){[220,330,440,554,660].forEach((f,i)=>this.tone(t+i*.13,f,.65,.045,'triangle',f));this.grit(t,.4,.07,180);return;}
 if(kind==='armor-hit'){this.tone(t,105,.12,.07,'triangle',42);this.tone(t,1750,.14,.035,'sine',900);this.grit(t,.065,.09,1700);return;}
 if(kind==='monster-arrow-hit'||kind==='arrow-armor'||kind==='arrow-finish'){const w=Math.max(.3,Math.min(1.9,type||1)),p=tier||1,armor=kind==='arrow-armor';this.grit(t,.018,.12*w,armor?3400:1900);this.tone(t,105*p,.09,.065*w,'triangle',38*p);this.grit(t+.008,.10,.065*w,armor?1000:350);this.tone(t+.015,65*p,.17,.04*w,'sine',28);if(armor)this.tone(t+.004,1800*p,.09,.025,'sine',900*p);if(kind==='arrow-finish')this.grit(t+.035,.16,.07*w,260);return;}
 if(kind==='arrow-hit'||kind==='bullseye'){this.grit(t,.06,.09,650);this.tone(t,kind==='bullseye'?1046:740,.16,.045,'sine',kind==='bullseye'?1568:900);return;}
 if(kind==='bow-release'){const c=Math.max(.18,Math.min(1,type||1)),p=tier||1;this.grit(t,.022,.07*c,3300*p);this.tone(t,310*p,.075,.055*c,'triangle',85*p);this.tone(t+.008,145*p,.13,.035*c,'sine',50*p);this.grit(t+.015,.09,.035*c,650*p);return;}
 if(kind==='swoosh'){this.grit(t,.075,.035,1800);return;}
 if(kind==='strike'){this.tone(t,145,.09,.065,'triangle',65);this.grit(t,.055,.09,750);this.tone(t+.004,1260,.09,.018,'sine',820);return;}
 if(kind==='hurt'){this.tone(t,88,.14,.06,'triangle',42);this.grit(t,.1,.055,340);return;}
 if(kind==='chest-open'){this.grit(t,.15,.045,260);this.tone(t,145,.12,.035,'triangle',65);this.grit(t+.12,.06,.035,2100);[620,830,1040].forEach((f,i)=>this.tone(t+.15+i*.055,f,.18,.018,'sine',f*.96));return;}
 if(kind==='rare-loot'){[220,330,440,659,880].forEach((f,i)=>this.tone(t+i*.075,f,.52,.025,'sine',f));this.grit(t,.16,.025,900);return;}
 if(kind==='pickup'){const v=[.96,1,1.04][this.variant++%3];this.tone(t,1080*v,.055,.012,'sine',760*v);this.tone(t+.032,1480*v,.10,.010,'sine',1210*v);return;}
 if(kind==='sell'||kind==='upgrade'){const notes=kind==='upgrade'?[440,554.37,659.25,880]:[523.25,659.25,783.99];notes.forEach((f,i)=>this.tone(t+i*.065,f,.25,.035,'sine',f));return;}
 if(type===8&&(kind==='hit'||kind==='break')){this.tone(t,kind==='hit'?155:100,.1,.055,'triangle',65);this.grit(t,kind==='hit'?.045:.13,.10,550);return;}
 const v=[.94,1.03,.98,1.07,1][this.variant++%5],f=(type===0?125:type===1?192:270)*v;
 if(kind==='hit'){this.tone(t,f,.085,.055,'triangle',f*.52);this.grit(t,.065,.1,1100+type*550);if(type>0)this.tone(t+.003,f*3.05,.105,.014+type*.004,'sine',f*2.9);if(tier>0)this.tone(t,f*1.5,.07,.012,'triangle');}
 else if(kind==='break'){this.tone(t,f*.7,.12,.075,'triangle',45);this.grit(t,.13,.15,750+type*500);for(let i=0;i<3;i++)this.grit(t+.025+i*.03,.04,.035,1400+i*650);if(type===2)this.tone(t+.025,920,.23,.018,'sine',1050);}
 }
 environment(index,active){
 if(!this.context||!this.noise)return;const c=this.context,t=c.currentTime;
 if(!this.ambient){this.ambient=c.createBufferSource();this.ambient.buffer=this.noise;this.ambient.loop=true;this.ambientFilter=c.createBiquadFilter();this.ambientFilter.type='lowpass';this.ambientGain=c.createGain();this.ambientGain.gain.value=0;this.ambient.connect(this.ambientFilter);this.ambientFilter.connect(this.ambientGain);this.ambientGain.connect(this.master??c.destination);this.ambient.start();}
 if(this.ambientMine!==index){this.ambientMine=index;this.ambientFilter.frequency.setTargetAtTime([420,115,680,82,650][index],t,.5);}
 this.ambientGain.gain.setTargetAtTime(this.muted||!active?0:[.010,.021,.007,.026,.009][index],t,.2);
 }

 setVolume(value){this.volume=Math.max(0,Math.min(1,value));if(this.master)this.master.gain.setTargetAtTime(this.volume,this.context.currentTime,.03);}

}
