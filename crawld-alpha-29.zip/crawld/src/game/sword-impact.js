const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
// Bounded contact feedback; damage and the player's movement clock remain separate.
export function swordImpact(spec,damage,maxHp,{armored=false,boss=false,killed=false,reduced=false}={}){
 const weight=spec.impact??1,strength=clamp(weight*(.82+clamp(damage/85,0,.42))+(killed?.12:0),.85,1.9);
 return {strength,pitch:spec.pitch??1,stop:reduced?0:clamp(.024+strength*.017+(armored?.009:0)+(killed?.006:0),.035,.078),recoil:reduced?0:strength,
  reaction:clamp(.75+damage/Math.max(1,maxHp)+weight*.32,.85,1.8)*(boss?.55:1),push:boss?.45+weight*.13:(armored?2.7:4.8)*clamp(strength,.8,1.5),
  stagger:boss?0:(armored?.11:.20)*clamp(strength,.9,1.5)};
}
export function swordRecoil(age,weight,reduced=false){if(reduced||age<0||!Number.isFinite(age))return 0;return clamp(weight,0,1.9)*(1-Math.exp(-age*90))*Math.exp(-age*22)*1.8;}
