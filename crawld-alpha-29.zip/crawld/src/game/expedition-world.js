import * as T from '../../vendor/three.module.js?v=29';
import {Approach} from './approach.js?v=29';
import {Dungeon} from './dungeon.js?v=29';
import {Descent,descentHeight} from './descent.js?v=29';
// One immutable coordinate system for the entire expedition. Only UI/combat
// ownership changes at a threshold; the player and camera never move here.
export class ExpeditionWorld{
 constructor(scene,actor,difficulty=0,seed=Date.now()){
  this.scene=scene;this.parts=[];this.blockers=[];this.floorParts=[];
  const approach=new Approach(scene,{continuous:true});this.blockers.push(...approach.blockers);this.parts.push({d:approach,north:-13,south:41,base:0,floor:1,kind:'outside'});
  let top=-13,base=0;
  for(let floor=1;floor<=3;floor++){
   const stair=new Descent(scene,floor),offset=top-2;
   stair.root.position.set(.5,base,offset);stair.floorNumber=Math.max(1,floor-1);
   this.parts.push({d:stair,north:top-22,south:top,base,floor:Math.max(1,floor-1),kind:'stair',offset});
   base-=2.88;const originZ=top-27;
   const d=new Dungeon(scene,actor,(seed+floor*19391)>>>0,difficulty,floor,{continuous:true,originZ,baseY:base});
   const north=d.rooms.at(-1).z-7,part={d,north,south:top-22,base,floor,kind:'floor'};
   this.parts.push(part);this.floorParts.push(part);this.blockers.push(...d.blockers);
   if(floor<3){
    // The seal is a physical gate. Opening it does not recreate either floor.
    const z=north+.3,gate=new T.Group(),mat=new T.MeshStandardMaterial({color:0x65705a,roughness:.85});
    for(let x=-1.6;x<=1.7;x+=.4){const bar=new T.Mesh(new T.BoxGeometry(.12,3.4,.18),mat);bar.position.set(x,2.7,z);gate.add(bar);}
    gate.position.y=base;d.root.add(gate);gate.position.y=0;
    const blocker=new T.Box3(new T.Vector3(-1.7,base+1,z-.16),new T.Vector3(2.2,base+4.5,z+.16));
    d.travelGate={mesh:gate,box:blocker,opened:false,lift:0};this.blockers.push(blocker);
   }
   top=north;
  }
 }
 partAt(p){return this.parts.find(s=>p.z>=s.north&&p.z<s.south)??(p.z>=-13?this.parts[0]:this.parts.at(-1));}
 solid(x,y,z){const s=this.partAt({z});if(s.kind==='outside')return y<1||Math.abs(x)>4.15||z>39.5;if(s.kind==='stair'){const lz=z-s.offset,h=descentHeight(lz)+s.base;return Math.abs(x-.5)>2.05||y<h||y>h+4;}return s.d.solid(x,y,z);}
 surfaceAt(p){const part=this.partAt(p);if(part.kind==='outside')return 1;if(part.kind==='stair')return 0;const r=part.d.rooms[part.d.roomAt(p)];if(!r)return 0;for(const side of [-1,1])if(Math.hypot(p.x-r.x-.5-side*((r.radius??4)-1.7),p.z-r.z-.5-side*.8)<1.05)return 2;return r.natural?1:0;}
 blocked(ray,distance){for(let t=.05;t<distance;t+=.1){const p=ray.at(t,new T.Vector3());if(this.solid(p.x,p.y,p.z)||this.blockers.some(b=>b.containsPoint(p)))return true;}return false;}
 openGate(d){const g=d.travelGate;if(!g||g.opened||!d.cleared)return false;g.opened=true;const n=this.blockers.indexOf(g.box);if(n>=0)this.blockers.splice(n,1);return true;}
 update(p,dt,reduced=false){const active=this.partAt(p);for(const s of this.parts){
   const near=p.z>s.north-28&&p.z<s.south+28;s.d.root.visible=near;
   if(s.d.combat?.enemies)for(const e of s.d.combat.enemies){e.root.visible=near&&(!e.dead||e.death>0);if(!near){e.lane.visible=false;e.marker.visible=false;}}
   if(near)s.d.update(p,dt,reduced);
   const gate=s.d.travelGate;if(gate?.opened){gate.lift=Math.min(3.8,gate.lift+dt*2.2);gate.mesh.position.y=gate.lift;}
   // Outdoor light fades with depth rather than lighting every buried room.
   if(s.kind==='outside')s.d.root.traverse(o=>{if(o.isLight){if(o.userData.fullPower===undefined)o.userData.fullPower=o.intensity;o.intensity=o.userData.fullPower*T.MathUtils.clamp((p.z+24)/11,0,1);}});
  }return active;}
 dispose(){for(const s of this.parts)s.d.dispose();this.parts=[];this.blockers=[];}
}
