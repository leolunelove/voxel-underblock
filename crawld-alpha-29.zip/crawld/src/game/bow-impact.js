const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function bowImpact(spec,charge,damage,maxHp,{armored=false,boss=false,killed=false}={}){
 const strength=clamp((spec.impact??1)*(.35+.65*charge)*(.85+Math.min(.35,damage/120)),.3,1.9);
 return {strength,pitch:spec.pitch??1,stop:0,recoil:0,reaction:clamp(.5+strength*.5+damage/Math.max(1,maxHp)*.3,.5,1.8)*(boss?.55:1),push:boss?.3*strength:(armored?2.3:4.2)*strength,stagger:boss?0:(armored?.08:.13)+strength*(armored?.055:.075)};
}
