// Distance drives the gait, so blocked input and airborne motion stay quiet.
export class Locomotion{
 constructor(){this.phase=0;this.amount=0;this.progress=.5;this.foot=0;this.events=[];}
 cue(kind,weight=1){if(this.events.length<8)this.events.push({kind,weight,foot:this.foot});}
 step(distance,dt,grounded,speed,sprint=false){
  const moving=grounded&&distance>1e-6,target=moving?Math.min(1.35,speed/4.3):0;
  this.amount+=(target-this.amount)*(1-Math.exp(-14*dt));
  if(!moving)return;
  const stride=sprint?1.95:1.75,advance=distance/stride;
  this.phase+=advance*Math.PI;this.progress+=advance;
  while(this.progress>=1){this.progress--;this.foot=1-this.foot;this.cue('footstep',sprint?1.16:.84+Math.min(.16,speed/30));}
 }
 view(reduced=false,steady=1){if(reduced)return {x:0,y:0};const a=this.amount*steady;return {x:Math.sin(this.phase)*.009*a,y:(Math.cos(this.phase*2)-1)*.009*a};}
 drain(){const cues=this.events;this.events=[];return cues;}
 stop(){this.amount=0;this.events=[];}
}
