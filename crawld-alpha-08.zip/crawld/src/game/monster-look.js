import * as T from '../../vendor/three.module.js?v=08';
const ease=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);};
export function dressMonster(root,body,head,arms,type){
 const armor=new T.MeshStandardMaterial({color:type===1?0x44515b:0x344b39,roughness:.82,metalness:type===1?.45:.04}),bone=new T.MeshLambertMaterial({color:0xd7c79f}),dark=new T.MeshLambertMaterial({color:0x202b28}),leather=new T.MeshLambertMaterial({color:0x664b34});
 const box=(parent,s,p,mat)=>{const o=new T.Mesh(new T.BoxGeometry(...s),mat);o.position.set(...p);parent.add(o);return o;};
 let jaw=null,shield=null;
 if(type===0){
 body.scale.set(1.08,.83,1.12);head.scale.set(1.16,.85,1.12);head.position.z=.18;
 box(body,[.96,.55,.35],[0,.15,-.35],armor);
 for(const x of [-.3,0,.3])box(body,[.12,.30,.15],[x,.49,-.29],bone);
 box(head,[.78,.12,.66],[0,.03,.02],armor);
 jaw=new T.Group();jaw.position.set(0,-.16,.07);head.add(jaw);box(jaw,[.72,.15,.62],[0,0,0],dark);
 for(const x of [-.25,.25]){box(jaw,[.10,.22,.11],[x,.06,.29],bone);box(head,[.09,.11,.1],[x,-.08,.31],bone);}
 for(const arm of arms){box(arm,[.28,.22,.30],[0,-.43,.02],armor);for(const x of [-.085,0,.085])box(arm,[.045,.27,.12],[x,-.72,.10],bone);}
 }else{
 box(head,[.82,.26,.70],[0,.24,0],armor);box(head,[.13,.50,.72],[0,.02,0],armor);box(head,[.86,.08,.73],[0,.12,0],dark);
 for(const arm of arms){box(arm,[.47,.29,.80],[0,-.04,0],armor);box(arm,[.31,.29,.34],[0,-.48,0],armor);}
 for(const y of [-.2,0,.2])box(body,[.88,.075,.05],[0,y,.36],bone);
 box(body,[.94,.12,.75],[0,-.35,0],leather);box(body,[.16,.16,.06],[0,-.34,.42],bone);
 shield=new T.Group();arms[0].add(shield);shield.position.set(0,-.47,.17);
 box(shield,[.66,.83,.16],[0,0,.05],armor);box(shield,[.55,.09,.20],[0,.32,.06],bone);box(shield,[.55,.09,.20],[0,-.32,.06],bone);box(shield,[.20,.22,.15],[0,0,.18],dark);
 box(arms[1],[.10,.75,.10],[0,-.65,.02],leather);box(arms[1],[.39,.38,.14],[.12,-.94,.03],armor);box(arms[1],[.08,.40,.16],[.32,-.94,.03],bone);
 }
 const bar=new T.Group();bar.position.set(0,2.18,0);box(bar,[.90,.085,.025],[0,0,0],dark);
 const lag=box(bar,[.82,.048,.03],[0,0,.018],new T.MeshBasicMaterial({color:0xb65e42})),fill=box(bar,[.82,.048,.03],[0,0,.025],new T.MeshBasicMaterial({color:0xe8bc71}));
 bar.traverse(o=>o.userData.effect=true);root.add(bar);bar.visible=false;
 return {head,armor,bar,fill,lag,jaw,shield,time:0,displayHP:1};
}
export function animateMonster(e,dt,reduced,distance){
 const v=e.look;if(!v)return;v.time+=dt;
 const brain=e.brain,a=brain.attack,wind=brain.state==='windup',active=brain.state==='active',recover=brain.state==='recovery',crawl=e.type===0;
 const hit=Math.max(0,Math.min(1,e.hit/.27)),recoil=hit*hit*(e.impactStrength??1),side=e.slashSide??1,charge=ease(brain.progress),cut=active?ease(1-brain.remaining/a.active):0;
 const moving=brain.state==='idle'&&distance>(crawl?2.7:1.95)&&distance<14&&e.stagger<=0;
 v.hitTime=e.hit>0?2:Math.max(0,(v.hitTime??0)-dt);v.bar.visible=e.hp<e.maxHp&&v.hitTime>0;
 const hp=e.hp/e.maxHp;v.displayHP=Math.max(hp,v.displayHP-dt*.75);v.fill.scale.x=Math.max(.001,hp);v.fill.position.x=-(1-hp)*.41;v.lag.scale.x=Math.max(.001,v.displayHP);v.lag.position.x=-(1-v.displayHP)*.41;
 v.armor.emissive.setHex(e.hit>0?0x95613f:wind?0x633b14:0);v.armor.emissiveIntensity=e.hit>0?hit*.9:wind?charge*.24:0;
 if(reduced){v.head.rotation.set(0,0,0);e.body.rotation.set(0,0,0);e.root.position.y=1;e.arms.forEach(x=>x.rotation.set(0,0,0));e.legs.forEach(x=>x.rotation.set(0,0,0));if(v.jaw)v.jaw.rotation.x=0;return;}
 const stride=Math.sin(e.timer),settle=recover?Math.min(1,brain.remaining/.35):0;
 e.root.position.y=1+(moving?Math.abs(stride)*(crawl?.065:.035):Math.sin(v.time*2.4)*.012)-(wind&&crawl?charge*.24:0)+(active&&crawl?Math.sin(cut*Math.PI)*.32:0);
 e.body.rotation.set((crawl?.16:0)+(wind?charge*(crawl?.20:-.12):active?.20*cut:recover?.12*settle:0),wind&&!crawl?-charge*.18:0,recoil*(crawl?.38:.18)*side+(moving?stride*.035:0));
 v.head.rotation.set(-recoil*.38+(wind?-charge*.24:active?.16:0),moving?Math.sin(e.timer*.5)*.045:0,-recoil*.28*side);
 if(v.jaw)v.jaw.rotation.x=wind?-charge*.48:active?-.5*(1-cut):-.06;
 e.arms.forEach((arm,i)=>{
 const sign=i===0?-1:1;let x=moving?Math.sin(e.timer+i*Math.PI)*(crawl?.65:.23):crawl?-.25:.12,z=crawl?sign*.13:sign*.04,y=0;
 if(wind){if(crawl){x=-.4-charge*1.5;z=sign*(.15+charge*.65);}else if(a.id==='bash'){x=i===0?-.8-charge*.25:-.25;z=i===0?-.24:charge*.20;}else{x=i===1?-charge*2.65:-.55;z=sign*charge*.14;y=i===1?-charge*.25:0;}}
 else if(active){if(crawl){x=-1.9+cut*2.9;z=sign*(.8-cut*.7);}else if(a.id==='bash'){x=i===0?-1.6+cut*.5:.4;z=i===0?.15:0;}else{x=i===1?-2.65+cut*3.6:-.45;z=i===1?cut*.22:0;}}
 else if(recover){x=crawl?.45*settle:i===1?.85*settle:-.25;}
 x+=recoil*.65;z+=sign*recoil*.28;arm.rotation.set(x,y,z);
 });
 e.legs.forEach((leg,i)=>{leg.rotation.x=moving?Math.sin(e.timer+i*Math.PI)*(crawl?.52:.32):wind&&crawl?-.3*charge:0;leg.rotation.z=crawl?(i===0?-.10:.10):0;});
}
