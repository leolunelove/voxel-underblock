import * as T from '../../vendor/three.module.js?v=08';
// Presentation is independent of damage and reward rules.
export function dressWarden(root,arms){
 const steel=new T.MeshStandardMaterial({color:0x343845,metalness:.65,roughness:.4}),gold=new T.MeshStandardMaterial({color:0xbb9560,metalness:.7,roughness:.35}),dark=new T.MeshLambertMaterial({color:0x171e28}),glow=new T.MeshBasicMaterial({color:0xffcb79});
 const box=(parent,w,h,d,x,y,z,mat)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),mat);o.position.set(x,y,z);parent.add(o);return o;};
 box(root,.96,.7,.76,0,.94,0,steel);box(root,.12,.65,.05,0,.98,.41,gold);box(root,.56,.12,.06,0,1.55,.32,dark);box(root,.52,.045,.07,0,1.57,.36,glow);box(root,.8,.18,.7,0,1.8,0,steel);
 for(const side of [-1,1]){box(arms[side===-1?0:1],.48,.30,.85,0,-.02,0,steel);box(arms[side===-1?0:1],.51,.07,.90,0,.14,0,gold);box(root,.33,.38,.4,side*.25,.22,.05,steel);box(root,.15,.34,.18,side*.35,1.97,0,gold);}
 box(root,.14,.46,.18,0,2.03,0,gold);box(root,.55,.62,.12,0,.58,-.43,dark);box(root,.28,.32,.08,0,1.0,.45,gold);for(const x of [-.28,.28])for(let j=0;j<3;j++)box(root,.09,.13,.09,x,.6-j*.14,.43,gold);
 const hammer=new T.Group();hammer.name='warden-hammer';arms[1].add(hammer);box(hammer,.12,1.15,.12,0,-.35,.05,dark);box(hammer,.62,.42,.55,0,-.9,.05,steel);box(hammer,.67,.12,.58,0,-.9,.05,gold);
 const shock=new T.Mesh(new T.RingGeometry(.92,1,40),new T.MeshBasicMaterial({color:0xffce83,side:T.DoubleSide,transparent:true,opacity:0,depthWrite:false}));shock.rotation.x=-Math.PI/2;shock.position.y=.035;root.add(shock);shock.userData.effect=true;
 return {shock,gold,steel,glow};
}
export function animateWarden(e,reduced){const v=e.warden;if(!v)return;const brain=e.brain,a=brain.attack,raw=brain.progress,charge=raw*raw*(3-2*raw),active=brain.state==='active',cut=active?1-brain.remaining/a.active:0,recovery=brain.state==='recovery'?Math.min(1,brain.remaining/.45):0;
 if(e.dead){v.shock.visible=false;return;}
 e.root.position.y=1;
 if(!reduced){
 e.arms[0].rotation.set(.08,0,-.04);e.arms[1].rotation.set(.10,0,.04);
 if(e.windup>0){
 if(a.id==='sweep'){e.arms[1].rotation.set(-charge*.9,-charge*.65,-charge*1.7);e.body.rotation.y=-charge*.22;e.root.rotation.x=-charge*.08;}
 else if(a.id==='charge'){e.arms[0].rotation.x=-1.1;e.arms[1].rotation.x=.35;e.root.rotation.x=charge*.34;e.body.rotation.y=0;}
 else{e.arms[1].rotation.x=-charge*2.8;e.arms[0].rotation.x=-charge*1.1;e.root.rotation.x=-charge*.16;e.body.rotation.y=0;}
 }else if(active){
 if(a.id==='sweep'){e.arms[1].rotation.set(-.9+cut*1.6,-.65+cut*1.2,-1.7+cut*3.2);e.body.rotation.y=-.22+cut*.55;}
 else if(a.id==='charge'){e.arms[0].rotation.x=-1.1;e.arms[1].rotation.x=.35;e.root.rotation.x=.42;}
 else{e.arms[1].rotation.x=-2.8+cut*3.9;e.arms[0].rotation.x=-1.1+cut*1.4;e.root.rotation.x=-.16+cut*.46;}
 }else{e.body.rotation.y*=.82;e.arms[1].rotation.x=.9*recovery;e.root.rotation.x=.18*recovery;if(brain.state==='idle'){const stride=Math.sin(e.timer);e.root.position.y+=Math.abs(stride)*.025;e.arms[0].rotation.x=stride*.15;e.arms[1].rotation.x=-stride*.10;}}
 const recoil=Math.max(0,Math.min(1,e.hit/.27))**2;e.body.rotation.z=recoil*.12*(e.slashSide??1);e.root.rotation.x-=recoil*.12;
 }else{e.body.rotation.set(0,0,0);e.arms.forEach(x=>x.rotation.set(0,0,0));e.legs.forEach(x=>x.rotation.set(0,0,0));}
 v.glow.color.setHex(e.windup>0?0xffebbc:brain.enraged?0xff8051:0xffcb79);
 v.steel.emissive.setHex(e.hit>0?0x754a30:brain.enraged?0x451b0a:0);v.steel.emissiveIntensity=e.hit>0?e.hit/.27:brain.enraged?.28:0;
 v.shock.visible=(e.shockTime??0)>0&&a?.id==='slam';v.shock.scale.setScalar(reduced?3.15:3.15*(1-(e.shockTime??0)/.45));v.shock.material.opacity=(e.shockTime??0)/.45*.8;
}
