import * as T from '../../vendor/three.module.js?v=20';
// One safe trail, a rugged threshold, and a clear warm light to lead you inside.
export class Approach{
 constructor(scene){
 this.scene=scene;this.isApproach=true;this.root=new T.Group();scene.add(this.root);this.rooms=[{x:0,z:0,style:'Ashen foothills'}];this.visited=new Set([0]);this.blockers=[];this.treasures=[];this.secrets=[];this.cleared=false;this.atExit=false;this.time=0;this.mist=[];this.fires=[];this.textures=[];this.combat={enemies:[],targets:[],cues:[],update:()=>({defeated:false})};
 let seed=821;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const rockGeometry=new T.IcosahedronGeometry(1,0),v=rockGeometry.attributes.position,colors=[];
 for(let i=0;i<v.count;i++){const shade=.69+Math.floor(i/3)%7*.042,c=new T.Color().setRGB(shade*.94,shade,shade*.88);colors.push(c.r,c.g,c.b);}rockGeometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));
 const boxGeometry=new T.BoxGeometry(1,1,1),batches=new Map(),q=new T.Quaternion(),euler=new T.Euler();
 const put=(geo,color,size,pos,rotation=[0,0,0])=>{const key=geo.uuid+color;if(!batches.has(key))batches.set(key,{geo,color,parts:[]});q.setFromEuler(euler.fromArray(rotation));batches.get(key).parts.push(new T.Matrix4().compose(new T.Vector3(...pos),q.clone(),new T.Vector3(...size)));};
 const box=(size,pos,color,rotation)=>put(boxGeometry,color,size,pos,rotation);
 const rock=(size,pos,color=0x69766b)=>put(rockGeometry,color,size,pos,[(rand()-.5)*.45,rand()*6.28,(rand()-.5)*.5]);
 box([120,1,120],[0,.5,-15],0x303d30);
 // A worn ribbon through scree: irregular shoulders rather than a paved corridor.
 const points=[],indices=[],groundColors=[];
 for(let i=0;i<=27;i++){const z=14-i,center=Math.sin(z*.22)*.28,width=2.25+rand()*.5;for(const side of [-1,1]){points.push(center+side*width,1.012,z);const c=new T.Color(0x514c3a).multiplyScalar(.85+rand()*.25);groundColors.push(c.r,c.g,c.b);}if(i<27){const a=i*2;indices.push(a,a+2,a+1,a+1,a+2,a+3);}}
 const path=new T.BufferGeometry();path.setAttribute('position',new T.Float32BufferAttribute(points,3));path.setAttribute('color',new T.Float32BufferAttribute(groundColors,3));path.setIndex(indices);path.computeVertexNormals();const trail=new T.Mesh(path,new T.MeshStandardMaterial({vertexColors:true,roughness:1,side:T.DoubleSide}));this.root.add(trail);
 for(let i=0;i<160;i++){const z=-12+rand()*26,x=(rand()-.5)*7.5;rock([.06+rand()*.19,.025+rand()*.06,.08+rand()*.18],[x,1.04,z],i%4===0?0x777967:0x4f5b4e);}
 for(const side of [-1,1])for(let i=0;i<16;i++){const z=13-i*1.8,x=side*(5.4+rand()*1.3);rock([1.3+rand()*1.2,.6+rand()*1.4,1+rand()*1.2],[x,1.3+rand()*.3,z],i%2?0x4b5c4c:0x626f5e);}
 // Offset, tilted faces break the old symmetrical wall into a mountain flank.
 for(const side of [-1,1])for(let row=0;row<3;row++)for(let i=0;i<7;i++){
 const x=side*(5+i*3.6)+rand()*.7,z=-16-row*3.6+rand()*1.6,y=3+row*3.3+rand()*1.3;
 rock([3.3+rand()*1.7,3.2+rand()*2.1,3+rand()*2.5],[x,y,z],row===0?0x74816c:0x687969);
 }
 for(const [x,y,z,s]of [[-3.6,3.1,-12.9,2.1],[3.8,3.4,-13.3,2.3],[-2.6,5.7,-13.5,1.8],[2.3,5.9,-13.8,1.9],[-.7,7.1,-14.3,2.2],[1.4,7.5,-15.5,2.7]])rock([s,s*1.25,s*1.3],[x,y,z],0x77836f);
 for(const side of [-1,1])this.blockers.push(new T.Box3(new T.Vector3(side<0?-4.2:2.3,1,-13.5),new T.Vector3(side<0?-2.3:4.2,5,-11.8)));
 // Recessed darkness and overlapping stones hide the edge of the cave backing.
 box([6,5.7,.4],[0,3.4,-19],0x080e0b);
 for(const side of [-1,1])for(let i=0;i<3;i++)rock([1.4,2.5,2],[side*3.1,3,-15-i*1.4],0x364638);
 const spikeGeo=new T.ConeGeometry(1,1,5);for(let i=0;i<5;i++)put(spikeGeo,0x596b58,[.18+rand()*.2,.5+rand()*.65,.2],[i*.7-1.4,5.8,-14.6],[Math.PI,rand()*6,0]);
 for(const [x,h,z,r]of [[-15,25,-32,20],[19,31,-40,23],[-7,40,-62,27],[37,24,-57,20]]){
 const geo=new T.ConeGeometry(r,h,6),peak=new T.Mesh(geo,new T.MeshStandardMaterial({color:z< -50?0x647d73:0x647564,roughness:1,flatShading:true}));peak.position.set(x,1+h/2,z);peak.rotation.y=rand()*3;this.root.add(peak);
 }
 // Wind-bitten spruce, moss, dry grasses and fallen timber keep the trail lived in.
 const foliage=new T.ConeGeometry(1,1,5);
 for(const side of [-1,1])for(let i=0;i<8;i++){const x=side*(8+rand()*10),z=14-i*4.5+rand()*2,h=3+rand()*3;box([.25,h,.3],[x,1+h/2,z],0x3d4030,[0,0,(rand()-.5)*.13]);for(let j=0;j<3;j++)put(foliage,0x273e32,[1.7-j*.36,h*.6,1.7-j*.36],[x,2+h*.3+j*.75,z],[0,rand()*3,0]);}
 for(let i=0;i<85;i++){const side=i%2?1:-1,x=side*(3.2+rand()*4),z=-10+rand()*24;rock([.35+rand()*.5,.07,.3],[x,1.04,z],0x3b5135);for(let j=0;j<3;j++)box([.045,.15+rand()*.33,.035],[x+j*.09,1.16,z],i%3?0x58624a:0x7a7250,[0,rand()*4,(rand()-.5)*.5]);}
 box([.35,.35,3.4],[-4.5,1.15,4],0x42432e,[0,.48,.1]);box([.24,.24,1.7],[-3.6,1.13,5],0x50513a,[0,-.7,.15]);
 // Remnants of an old expedition, just off the clear walking line.
 box([.22,1.75,.22],[-3.4,1.8,-5],0x4a4430,[0,0,-.16]);box([1.35,.18,.18],[-3.53,2.4,-5],0x5c5338,[0,0,-.12]);box([.6,.45,.5],[3.5,1.25,-7.5],0x544834,[0,.3,0]);box([.65,.06,.55],[3.5,1.5,-7.5],0x303b30,[0,.3,0]);
 // Warm braziers give the only visual destination; nothing opens a side route.
 for(const side of [-1,1]){const x=side*2.25;box([.16,1.25,.16],[x,1.65,-10.6],0x3b3428);box([.42,.16,.42],[x,2.28,-10.6],0x2a322b);for(const dx of [-.16,.16])box([.04,.35,.04],[x+dx,2.48,-10.6],0x414a3a);const fire=new T.Mesh(new T.BoxGeometry(.17,.28,.17),new T.MeshBasicMaterial({color:0xe9bc76}));fire.position.set(x,2.48,-10.6);this.root.add(fire);const lamp=new T.PointLight(0xffb86b,9,11,2);lamp.position.set(x,2.9,-10.5);this.root.add(lamp);this.fires.push({fire,lamp,phase:rand()*6});}
 for(const batch of batches.values()){const mesh=new T.InstancedMesh(batch.geo,new T.MeshStandardMaterial({color:batch.color,vertexColors:batch.geo===rockGeometry,roughness:1,flatShading:true}),batch.parts.length);batch.parts.forEach((m,i)=>mesh.setMatrixAt(i,m));this.root.add(mesh);}
 // Soft low sheets, rather than opaque fog walls across the route.
 const size=64,data=new Uint8Array(size*size*4);for(let y=0;y<size;y++)for(let x=0;x<size;x++){const u=(x-31.5)/32,w=(y-31.5)/32,edge=Math.max(0,1-u*u-w*w),i=(y*size+x)*4,cloud=.65+.2*Math.sin(x*.25+y*.17)+.15*Math.sin(x*.11-y*.31);data[i]=data[i+1]=data[i+2]=255;data[i+3]=Math.round(edge*edge*cloud*140);}
 const mistTexture=new T.DataTexture(data,size,size);mistTexture.magFilter=mistTexture.minFilter=T.LinearFilter;mistTexture.needsUpdate=true;this.textures.push(mistTexture);
 for(let i=0;i<10;i++){const sprite=new T.Sprite(new T.SpriteMaterial({map:mistTexture,color:0xa4bbad,transparent:true,opacity:.15,depthWrite:false}));sprite.position.set((i%2?1:-1)*(2+rand()*4),1.25+rand()*.8,12-i*3.4);sprite.scale.set(10+rand()*5,1.1+rand()*.8,1);this.root.add(sprite);this.mist.push({sprite,x:sprite.position.x,phase:rand()*6});}
 this.root.add(new T.HemisphereLight(0xb4c6c4,0x485237,1.25));const moon=new T.DirectionalLight(0xc6cfba,1.8);moon.position.set(-15,25,12);this.root.add(moon);
 }
 entranceAvailable(p){return p.z< -9&&Math.abs(p.x)<2;}
 roomAt(){return 0;}solid(x,y,z){return y<1||Math.abs(x)>4.15||z>13||z< -13.5;}
 blocked(ray,distance){for(let d=.1;d<distance;d+=.12){const p=ray.at(d,new T.Vector3());if(this.solid(p.x,p.y,p.z)||this.blockers.some(b=>b.containsPoint(p)))return true;}return false;}
 update(position,dt=0,reduced=false){this.time+=dt;for(const m of this.mist){m.sprite.position.x=m.x+(reduced?0:Math.sin(this.time*.12+m.phase)*.8);m.sprite.material.opacity=reduced?.13:.13+Math.sin(this.time*.22+m.phase)*.025;}for(const f of this.fires){const pulse=reduced?1:1+Math.sin(this.time*9+f.phase)*.045;f.fire.scale.y=pulse;f.lamp.intensity=9*pulse;}}
 secretAvailable(){return null;}treasureAvailable(){return null;}cacheAvailable(){return false;}
 dispose(){this.root.removeFromParent();const gs=new Set(),ms=new Set();this.root.traverse(o=>{if(o.geometry)gs.add(o.geometry);if(o.material)ms.add(o.material);if(o.isInstancedMesh)o.dispose();});this.textures.forEach(t=>t.dispose());gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());}
}
