import * as T from '../../vendor/three.module.js?v=21';
export function caveTexture(seed){const size=64,data=new Uint8Array(size*size*4);let n=seed>>>0;for(let y=0;y<size;y++)for(let x=0;x<size;x++){n=(Math.imul(n,1664525)+1013904223)>>>0;const cell=((Math.floor(x/7)*23+Math.floor(y/5)*37+seed)>>>0)%29,shade=108+n%18+cell*.7+(y%13===0?-12:0),i=(y*size+x)*4;data[i]=shade*.85;data[i+1]=shade;data[i+2]=shade*.84;data[i+3]=255;}const t=new T.DataTexture(data,size,size);t.colorSpace=T.SRGBColorSpace;t.magFilter=t.minFilter=T.NearestFilter;t.needsUpdate=true;return t;}
export function dressCaverns(d){
 let seed=d.seed;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};const geometry=new T.IcosahedronGeometry(1,0),positions=geometry.attributes.position,colors=[];for(let i=0;i<positions.count;i++){const v=.7+(Math.floor(i/3)%6)*.045;colors.push(v*.93,v,v*.86);}geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));const matrices=[],quaternion=new T.Quaternion(),rotation=new T.Euler();
 const rock=(x,y,z,w,h,depth)=>{quaternion.setFromEuler(rotation.set((rand()-.5)*.5,rand()*6,(rand()-.5)*.6));matrices.push(new T.Matrix4().compose(new T.Vector3(x,y,z),quaternion.clone(),new T.Vector3(w,h,depth)));};
 // Every corridor keeps a generous clear core; rock intrudes only at the shoulders.
 for(const link of d.links){if(link.secret)continue;const a=d.rooms[link.a],b=d.rooms[link.b],dx=Math.sign(b.x-a.x),dz=Math.sign(b.z-a.z),distance=Math.abs(a.x-b.x)+Math.abs(a.z-b.z);for(let k=(a.radius??4)+.5;k<distance-(b.radius??4);k+=1.35){const x=a.x+.5+dx*k,z=a.z+.5+dz*k;for(const side of [-1,1]){rock(x+dz*side*3.3,2.8,z+dx*side*3.3,dx?1.25:1.1,2+rand()*.55,dz?1.25:1.1);rock(x+dz*side*2.4,5.8,z+dx*side*2.4,1.5,.85+rand()*.25,1.5);}rock(x,6.2,z,1.5,.5,1.5);}}
 for(const r of d.rooms){const neighbors=d.links.filter(l=>d.rooms[l.a]===r||d.rooms[l.b]===r).map(l=>d.rooms[l.a]===r?d.rooms[l.b]:d.rooms[l.a]);const radius=r.radius??4,ceiling=r.ceiling??5,cx=r.x+.5,cz=r.z+.5;
 // The opening chamber is all rock. Ruins retain masonry between broken buttresses.
 for(const side of [-1,1])for(let k=-radius;k<=radius;k+=1.8){if(r.natural||rand()>.45){if(!neighbors.some(n=>Math.sign(n.x-r.x)===side&&n.z===r.z&&Math.abs(k)<3.4))rock(cx+side*(radius+.5),2.9,cz+k,1.5,2.4,1.5);if(!neighbors.some(n=>Math.sign(n.z-r.z)===side&&n.x===r.x&&Math.abs(k)<3.4))rock(cx+k,2.9,cz+side*(radius+.5),1.5,2.4,1.5);}if(r.natural){rock(cx+side*(radius-.6),ceiling-.25,cz+k,1.8,.8,1.6);rock(cx+k,ceiling-.25,cz+side*(radius-.6),1.6,.8,1.8);}}
 if(r.natural)for(let x=-2;x<=2;x+=2)for(let z=-2;z<=2;z+=2)rock(cx+x,ceiling+.1,cz+z,1.8,.55,1.8);
 // Small rubble lies flush with the floor, clear of the fighting and walking plane.
 for(let i=0;i<22;i++){const side=i%2?1:-1,x=cx+side*(radius-1+rand()*.6),z=cz+(rand()-.5)*radius*1.7;rock(x,1.03,z,.12+rand()*.3,.055,.12+rand()*.3);}
 }
 // Thin shelves, moss stains and tapered hanging stone soften the large facets.
 const shelves=[],moss=[],spikes=[],pools=[],q=new T.Quaternion(),matrix=new T.Matrix4();
 const stamp=(list,x,y,z,w,h,depth,rx=0,ry=0)=>{q.setFromEuler(new T.Euler(rx,ry,0));list.push(new T.Matrix4().compose(new T.Vector3(x,y,z),q.clone(),new T.Vector3(w,h,depth)));};
 for(const r of d.rooms){const radius=r.radius??4,cx=r.x+.5,cz=r.z+.5,ceiling=r.ceiling??5;
 for(const side of [-1,1])for(let k=-radius+1;k<=radius-1;k+=2){
 // Stay clear of every possible doorway and the centre of the fight space.
 if(Math.abs(k)<3.4)continue;
 for(const y of [1.6,3.4,4.7])stamp(shelves,cx+side*(radius-.3),y,cz+k,.8,.19+rand()*.14,1.5,0,rand()*.4);
 stamp(moss,cx+side*(radius-.55),1.18,cz+k,.6,.16,1.1,0,rand()*2);
 }
 for(let i=0;i<(r.natural?15:5);i++){const a=rand()*6.28,reach=(radius-1)*(.65+rand()*.3),h=.4+rand()*.8;stamp(spikes,cx+Math.cos(a)*reach,ceiling-h/2-.15,cz+Math.sin(a)*reach,.15+rand()*.25,h,.2+rand()*.25,Math.PI,rand()*6);}
 for(const side of [-1,1])stamp(pools,cx+side*(radius-1.7),1.019,cz+side*.8,1+rand()*.6,.7+rand()*.45,1,-Math.PI/2,0);
 }
 const instance=(geo,material,parts,name)=>{const m=new T.InstancedMesh(geo,material,parts.length);m.name=name;parts.forEach((p,i)=>m.setMatrixAt(i,p));d.root.add(m);return m;};
 instance(geometry,new T.MeshStandardMaterial({color:0x839078,map:d.textures[3],vertexColors:true,roughness:.96}),shelves,'sedimentary-shelves');
 instance(geometry,new T.MeshStandardMaterial({color:0x3d5437,vertexColors:true,roughness:1}),moss,'damp-cave-moss');
 instance(new T.ConeGeometry(1,1,5),new T.MeshStandardMaterial({color:0x7c8976,map:d.textures[3],roughness:.87,flatShading:true}),spikes,'hanging-stone');
 instance(new T.CircleGeometry(1,9),new T.MeshStandardMaterial({color:0x273d35,roughness:.21,metalness:.18,transparent:true,opacity:.68,depthWrite:false}),pools,'shallow-cave-pools');
 // Low, translucent air stays below enemy silhouettes and attack windups.
 const size=32,data=new Uint8Array(size*size*4);for(let y=0;y<size;y++)for(let x=0;x<size;x++){const edge=Math.max(0,1-((x-15.5)/16)**2-((y-15.5)/16)**2),i=(y*size+x)*4;data[i]=data[i+1]=data[i+2]=255;data[i+3]=Math.round(edge*edge*100);}const texture=new T.DataTexture(data,size,size);texture.magFilter=texture.minFilter=T.LinearFilter;texture.needsUpdate=true;d.textures.push(texture);d.caveHaze=[];
 for(const r of d.rooms){for(let i=0;i<(r.natural||r.kind==='shrine'?3:1);i++){const sprite=new T.Sprite(new T.SpriteMaterial({map:texture,color:0x93a68e,transparent:true,opacity:.08,depthWrite:false}));sprite.position.set(r.x+.5+(i-1)*1.7,1.25,r.z+.5+(i-1)*2);sprite.scale.set(7,.65,1);d.root.add(sprite);d.caveHaze.push({sprite,x:sprite.position.x,phase:rand()*6,strength:r.natural||r.kind==='shrine'?.07:.04});}}
 const dripGeo=new T.BoxGeometry(.014,.085,.014),drips=new T.InstancedMesh(dripGeo,new T.MeshBasicMaterial({color:0x9caa8e,transparent:true,opacity:.23,depthWrite:false}),18);drips.name='cave-drips';drips.frustumCulled=false;d.root.add(drips);d.caveDrips={mesh:drips,seeds:Array.from({length:18},()=>[rand(),rand(),rand()])};
 const mesh=new T.InstancedMesh(geometry,new T.MeshStandardMaterial({color:0xaab69c,map:d.textures[3],roughness:.94,flatShading:true,vertexColors:true}),matrices.length);mesh.name='rugged-cave-shell';matrices.forEach((m,i)=>mesh.setMatrixAt(i,m));d.root.add(mesh);
}

export function updateCaverns(d,position,reduced){for(const h of d.caveHaze??[]){h.sprite.position.x=h.x+(reduced?0:Math.sin(d.time*.14+h.phase)*.35);h.sprite.material.opacity=(h.strength??.07)+(reduced?0:Math.sin(d.time*.19+h.phase)*.009);}if(d.caveDrips){const r=d.rooms[d.roomAt(position)],active=!!r&&(r.natural||r.kind==='shrine'),m=new T.Matrix4();d.caveDrips.mesh.visible=active&&!reduced;if(active&&!reduced){d.caveDrips.seeds.forEach(([a,b,c],i)=>{const side=i%2?1:-1,span=(r.radius??4)-1;m.makeTranslation(r.x+.5+side*span,1.1+((b*4-d.time*1.5)%4+4)%4,r.z+.5+(c-.5)*span*1.5);d.caveDrips.mesh.setMatrixAt(i,m);});d.caveDrips.mesh.instanceMatrix.needsUpdate=true;}}}
