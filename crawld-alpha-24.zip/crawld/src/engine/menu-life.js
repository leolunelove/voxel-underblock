// CSS owns ambience; delegated controls survive menu and inventory rerenders.
export function bringMenuToLife(menu,modal,audio){
 const embers=menu.querySelector('.embers');
 const positions=[9,18,27,35,41,64,70,76,83,91,22,38,73,88];
 positions.forEach((left,i)=>{const p=document.createElement('i');p.style.cssText='left:'+left+'%;--rise:'+(12+i%6*2)+'s;--delay:'+(-i*2.7)+'s;--drift:'+((i%2?1:-1)*(14+i*3))+'px;--size:'+(i%4===0?3:2)+'px';embers.append(p);});
 let lastHover=-Infinity;
 const control=target=>target instanceof Element?target.closest('button,summary,input[type=checkbox]'):null;
 const inside=el=>el&&(menu.contains(el)&&!menu.hidden||modal.contains(el)&&!modal.hidden)&&!el.disabled;
 function hover(event){const el=control(event.target);if(!inside(el)||el.contains(event.relatedTarget)||audio.context?.state!=='running')return;const now=performance.now();if(now-lastHover<100)return;lastHover=now;audio.play('menu-hover');}
 document.addEventListener('pointerover',hover);
 document.addEventListener('focusin',event=>{if(event.target.matches?.(':focus-visible'))hover(event);});
 document.addEventListener('click',event=>{const el=control(event.target);if(!inside(el))return;audio.unlock();audio.play(el.id==='start'?'menu-enter':'menu-click');},true);
 const pause=()=>document.body.classList.toggle('page-hidden',document.hidden);document.addEventListener('visibilitychange',pause);pause();
}
