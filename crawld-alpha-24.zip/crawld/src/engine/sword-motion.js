// A diagonal cut across the body: windup, edge contact, broad follow-through.
// The opposite stroke mirrors the arc, so holding attack creates a calm two-cut rhythm.
export function swordSlashPose(phase,aspect,motion=1,side=1){
 const keys=[[0,.36,-.48,-1.88,-.22,-.22,-.32],[.17,.56,-.20,-1.70,.08,-.42,-1.10],[.24,.38,-.25,-1.88,-.30,-.24,-.75],[.30,.04,-.38,-2.08,-.68,.10,.20],[.44,-.54,-.60,-1.90,-1.00,.38,1.26],[.57,-.57,-.57,-1.78,-.75,.32,1.12],[.88,-.36,-.48,-1.88,-.22,.22,.32],[1,-.36,-.48,-1.88,-.22,.22,.32]];
 const rest=keys[0].slice(1);let pose=rest;
 for(let i=1;i<keys.length;i++){const a=keys[i-1],b=keys[i];if(phase<=b[0]){let t=Math.max(0,(phase-a[0])/(b[0]-a[0]));t=i===3?1-(1-t)*(1-t):t*t*(3-2*t);pose=a.slice(1).map((v,j)=>v+(b[j+1]-v)*t);break;}}
 const p=rest.map((v,i)=>v+(pose[i]-v)*motion),width=Math.tan(24*Math.PI/180)*1.9*Math.max(.45,aspect),narrow=Math.min(1,width/.76);
 // Keep the hilt within a narrow viewport while preserving the blade's diagonal arc.
 return {position:[p[0]*side*narrow,p[1],p[2]],rotation:[p[3],p[4]*side,p[5]*side]};
}
