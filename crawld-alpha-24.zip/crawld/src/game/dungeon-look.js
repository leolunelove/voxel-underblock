import * as T from '../../vendor/three.module.js?v=24';
const hash=(x,y,s)=>{let n=Math.imul(x+17,374761393)^Math.imul(y+31,668265263)^s;n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967296;};
export function stoneTexture(seed,brick=false){
 const size=128,data=new Uint8Array(size*size*4);
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
 const row=Math.floor(y/(brick?8:64)),shift=brick?(row%2)*32:0,bx=(x+shift)%64,by=y%(brick?8:64),tile=hash(Math.floor((x+shift)/64),row,seed),noise=hash(x,y,seed+73);
 const seam=bx<1||by<1,edge=bx===1||by===1,shade=seam?-48:edge?14:by===(brick?7:63)?-17:0;
 const base=98+tile*30+(noise-.5)*15+shade;
 const patch=hash(Math.floor(x/13),Math.floor(y/13),seed+102),moss=!seam&&patch>(brick?.76:.89)&&(noise>.25||by>4);
 const i=(y*size+x)*4;data[i]=Math.max(0,moss?base*.49:base*.96);data[i+1]=Math.max(0,moss?base*.67:base*1.01);data[i+2]=Math.max(0,moss?base*.39:base*.91);data[i+3]=255;
 }
 const t=new T.DataTexture(data,size,size);t.colorSpace=T.SRGBColorSpace;t.magFilter=t.minFilter=T.NearestFilter;t.wrapS=t.wrapT=T.RepeatWrapping;t.needsUpdate=true;return t;
}
export function flameTexture(){const size=32,d=new Uint8Array(size*size*4);for(let y=0;y<size;y++)for(let x=0;x<size;x++){const distance=Math.hypot((x-15.5)/16,(y-15.5)/16),i=(y*size+x)*4;d[i]=255;d[i+1]=170;d[i+2]=65;d[i+3]=Math.max(0,1-distance)**3*125;}const t=new T.DataTexture(d,size,size);t.needsUpdate=true;return t;}
export function dressDungeon(d,prop){
 d.arches=[];const stoneProp=(...args)=>{const mesh=prop(...args);mesh.material.map=d.textures[1];return mesh;};
 const arch=(x,z,alongX)=>{
 const root=new T.Group();root.name='masonry-arch';if(d.linear)root.scale.x=1.35;root.position.set(x,0,z);if(alongX)root.rotation.y=Math.PI/2;d.root.add(root);
 const block=(w,h,depth,px,y,color)=>{const o=prop(w,h,depth,0,0,0,color);root.add(o);o.position.set(px,y,0);o.material.map=d.textures[1];return o;};
 for(const side of [-1,1]){block(.50,3.4,.65,side*1.8,2.7,0x9b9a86);block(.68,.26,.83,side*1.8,1.13,0x777f6c);block(.65,.22,.8,side*1.8,4.25,0xa29c83);block(.66,.54,.65,side*1.25,4.62,0x989a85);block(.64,.35,.65,side*.65,4.85,0x9c9b89);}
 block(.66,.34,.73,0,4.91,0xb4a48a);d.arches.push(root);
 };
 for(const link of d.links){if(link.secret)continue;const a=d.rooms[link.a],b=d.rooms[link.b],dx=Math.sign(b.x-a.x),dz=Math.sign(b.z-a.z);for(const r of [a,b]){if(r.natural)continue;const sign=r===a?1:-1;arch(r.x+.5+dx*((r.radius??4)+.65)*sign,r.z+.5+dz*((r.radius??4)+.65)*sign,!!dx);}}
 for(const [i,r]of d.rooms.entries()){if(r.natural)continue;
 if((r.ceiling??5)>6){const span=r.radius??5;for(let j=-2;j<=2;j++){const gap=.5+hash(j,i,d.seed)*1.2,length=span-gap;for(const side of [-1,1])stoneProp(.4,.3,length,r.x+.5+j*1.8,(r.ceiling??5)-.5,r.z+.5+side*(span+gap)/2,0x59654f);}}
 // Stone caps, footings and hanging growth occupy the existing outer room edges.
 for(const dx of [-1,1].map(s=>s*((r.radius??4)-.35)))for(const dz of [-1,1].map(s=>s*((r.radius??4)-.35))){stoneProp(.82,.22,.82,r.x+.5+dx,1.11,r.z+.5+dz,0x687564);stoneProp(.86,.28,.86,r.x+.5+dx,(r.ceiling??5)-.25,r.z+.5+dz,0x878c78);}
 const lush=/Moss|Overgrown/.test(r.style);
 for(const side of [-1,1])for(let k=-3;k<=3;k++){
 if(hash(k,side,i+d.seed)>(lush?.18:.65)){
 const length=.25+hash(k,side,i+37)*1.1;
 for(let j=0;j<3;j++)prop(.15+hash(k,j,i)*.14,length*(1-j*.17),.14,r.x+.5+side*((r.radius??4)-.2),(r.ceiling??5)-.1-length*.5-j*.15,r.z+.5+k+j*.12,0x354d32);
 }
 if(hash(k,side,d.seed+i)>.52){const moss=prop(.5+hash(k,i,3)*.7,.008,.6+hash(i,k,5)*.5,r.x+.5+side*3.6,1.008,r.z+.5+k,0x3c5037);moss.material.map=d.textures[0];}
 }
 if(lush){for(const side of [-1,1]){const water=prop(1.35,.012,4.3,r.x+.5+side*2.9,1.014,r.z+.5,0x26423c);water.material.roughness=.24;water.material.metalness=.3;}}
 // Raised ceiling ribs leave more than 3.3m of headroom over the whole fight area.
 for(const side of [-1,1]){stoneProp(.32,.28,(r.radius??4)*2+.3,r.x+.5+side*((r.radius??4)-.35),(r.ceiling??5)-.15,r.z+.5,0x707b69);stoneProp((r.radius??4)*2+.3,.28,.32,r.x+.5,(r.ceiling??5)-.15,r.z+.5+side*((r.radius??4)-.35),0x707b69);}
 }
 const count=64,geometry=new T.BoxGeometry(.025,.025,.025),material=new T.MeshBasicMaterial({color:0xbdb58b,transparent:true,opacity:.20,depthWrite:false}),dust=new T.InstancedMesh(geometry,material,count);dust.name='ambient-dust';dust.frustumCulled=false;d.root.add(dust);d.dust={mesh:dust,seeds:Array.from({length:count},(_,i)=>[hash(i,1,d.seed),hash(i,2,d.seed),hash(i,3,d.seed)])};
}
export function updateAtmosphere(d,position,reduced,dt=0){
 const matrix=new T.Matrix4(),dust=d.dust;
 if(dust)for(let i=0;i<dust.seeds.length;i++){const [a,b,c]=dust.seeds[i],t=reduced?0:d.time;matrix.makeTranslation(position.x+(a-.5)*17+Math.sin(t*.13+i)*.10,1.3+b*3+Math.sin(t*.16+i)*.08,position.z+(c-.5)*17);dust.mesh.setMatrixAt(i,matrix);}if(dust)dust.mesh.instanceMatrix.needsUpdate=true;
 // A fixed light pool avoids a shader with dozens of lights as floors expand.
 d.lightClock=(d.lightClock??1)+dt;if(d.lightClock>.25||!d.nearTorches){d.lightClock=0;d.nearTorches=[...d.torches].sort((a,b)=>a.flame.position.distanceToSquared(position)-b.flame.position.distanceToSquared(position)).slice(0,d.lightPool.length);}
 d.lightPool.forEach((lamp,i)=>{const t=d.nearTorches[i];if(!t){lamp.intensity=0;return;}lamp.position.copy(t.flame.position).add(new T.Vector3(0,.12,0));lamp.color.copy(t.flame.material.color);const pulse=reduced?1:1+Math.sin(d.time*7+t.phase)*.06+Math.sin(d.time*13+t.phase)*.025;lamp.intensity=(t.power??27)*pulse;});
}
// Merge static box props into material batches; animated and interactive pieces stay separate.
export function batchDungeon(d){
 d.root.updateMatrixWorld(true);
 const dynamic=new Set([d.exit,d.cache,d.cacheLid,...d.treasures.flatMap(t=>[t.mesh,t.lid]),...d.secrets.flatMap(s=>[s.gate,...s.clue.children]),...d.torches.flatMap(t=>[t.flame,t.core,t.tip])]);
 const groups=new Map(),old=[];
 d.root.traverse(o=>{if(!o.isMesh||o.isInstancedMesh||dynamic.has(o)||o.userData.lootPart||!o.geometry.parameters?.width)return;const m=o.material,key=[m.type,m.color.getHex(),m.map?.uuid??'',m.roughness??'',m.metalness??''].join('/');if(!groups.has(key))groups.set(key,{material:m.clone(),objects:[]});groups.get(key).objects.push(o);old.push(o);});
 const unit=new T.BoxGeometry(1,1,1),matrix=new T.Matrix4(),inverse=d.root.matrixWorld.clone().invert();
 for(const group of groups.values()){const mesh=new T.InstancedMesh(unit,group.material,group.objects.length);mesh.name='static-stone-detail';group.objects.forEach((o,i)=>{const p=o.geometry.parameters;matrix.copy(inverse).multiply(o.matrixWorld).multiply(new T.Matrix4().makeScale(p.width,p.height,p.depth));mesh.setMatrixAt(i,matrix);});d.root.add(mesh);}
 const gs=new Set(),ms=new Set();for(const o of old){gs.add(o.geometry);ms.add(o.material);o.removeFromParent();}gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());
}
