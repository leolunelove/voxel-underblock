// Encounter timing and hit shapes are simulation rules, independent of rendering.
export const ATTACKS={
 pounce:{name:'POUNCE / MOVE OFF THE MARK',windup:.65,active:.24,recovery:1.0,range:3.1,reach:3.2,radius:.95,shape:'target',damage:.85,color:0xe9b565,move:2.2},
 overhead:{name:'OVERHEAD / BACKSTEP',windup:.95,active:.22,recovery:1.35,range:2.5,reach:2.65,angle:.65,shape:'cone',damage:1.15,color:0xe7ad59,move:0},
 bash:{name:'SHIELD BASH / SIDESTEP',windup:.55,active:.18,recovery:1.05,range:2.1,reach:2.3,angle:.55,shape:'cone',damage:.65,color:0xd8d29a,move:.5},
 slam:{name:'GROUND SLAM / JUMP OR BACKSTEP',windup:1.15,active:.26,recovery:1.6,range:3.2,reach:3.15,shape:'circle',damage:1,color:0xffb75f,move:0,low:true},
 sweep:{name:'HAMMER SWEEP / GET BEHIND OR BACKSTEP',windup:.95,active:.30,recovery:1.45,range:3.6,reach:3.65,angle:1.15,shape:'cone',damage:.85,color:0xe69bdc,move:0},
 charge:{name:'WARDEN CHARGE / SIDESTEP',windup:1.20,active:.40,recovery:1.8,range:7,reach:6,width:.8,shape:'lane',damage:1.15,color:0x83d8db,move:4.4}
};
export class EncounterBrain{
 constructor(type,boss=false){this.type=type;this.boss=boss;this.count=0;this.state='idle';this.remaining=.75;this.attack=null;this.enraged=false;}
 choose(){return this.boss?['slam','sweep','charge'][this.count%3]:this.type===0?'pounce':['overhead','bash'][this.count%2];}
 get progress(){return this.state==='windup'?1-this.remaining/this.windup:0;}
 interrupt(){if(this.state!=='windup'||this.boss||(this.type===1&&this.progress>.35))return false;this.state='recovery';this.remaining=.4;return true;}
 step(dt,distance,hpRatio=1){const events=[];this.enraged=this.boss&&hpRatio<=.5;
 if(this.state==='idle'||this.state==='recovery'){this.remaining=Math.max(0,this.remaining-dt);if(this.remaining===0){this.state='idle';const name=this.choose(),a=ATTACKS[name];if(distance<a.range){this.attack={...a,id:name};this.count++;this.windup=a.windup*(this.enraged?.84:1);this.remaining=this.windup;this.state='windup';events.push('start');}}return events;}
 const before=this.remaining;this.remaining=Math.max(0,this.remaining-dt);
 if(this.state==='windup'&&this.remaining===0){this.state='active';this.remaining=this.attack.active;events.push('commit');}
 else if(this.state==='active'&&this.remaining===0){events.push('impact');this.state='recovery';this.remaining=this.attack.recovery*(this.enraged?.8:1);}
 return events;}
}
export function attackHits(a,origin,target,player,heading){if(!a||Math.abs(player.y-((origin.y??1)+1.65))>(a.low?.55:1.8))return false;const dx=player.x-origin.x,dz=player.z-origin.z,d=Math.hypot(dx,dz),forward=dx*heading.x+dz*heading.z,side=dx*heading.z-dz*heading.x;
 if(a.shape==='target')return Math.hypot(player.x-target.x,player.z-target.z)<a.radius;
 if(a.shape==='circle')return d<a.reach;
 if(a.shape==='lane')return forward>=-.4&&forward<a.reach&&Math.abs(side)<a.width;
 return d<a.reach&&(d<.05||forward/d>Math.cos(a.angle));}
