export const RELICS={sword:{name:'Ashbound blade',field:'relicSword',description:'+15% sword damage'},bow:{name:'Hollowstring bow',field:'relicBow',description:'+15% bow damage'}};
export const relicPower=(actor,kind)=>actor[RELICS[kind].field]&&actor[kind==='sword'?'equipRelicSword':'equipRelicBow']!==false?1.15:1;
// A source rolls once per expedition. Finds are usable now, banked only on extraction.
export function rollWeaponLoot(run,actor,id,chance,roll=Math.random(),choice=Math.random()){
 if(run.ended||actor.hp<=0)return null;run.lootRolls??=[];run.relics??=[];
 const key=run.floor+':'+id;if(run.lootRolls.includes(key))return null;run.lootRolls.push(key);
 if(roll>=Math.max(0,Math.min(1,chance)))return null;
 const kind=choice<.5?'sword':'bow',spec=RELICS[kind];
 if(actor[spec.field]){actor.loot+=80;return {kind,...spec,duplicate:true,coins:80};}
 actor[spec.field]=true;actor[kind==='sword'?'equipRelicSword':'equipRelicBow']=true;run.relics.push(kind);return {kind,...spec,duplicate:false,coins:0};
}
