import test from 'node:test';
import assert from 'node:assert/strict';
import {createSword,createBow} from '../src/engine/weapon-look.js';
import {bowRig,applyBowRig} from '../src/engine/bow-motion.js';
test('all forged weapon tiers retain finite geometry and bow articulation through draw and release',()=>{
 for(let tier=0;tier<4;tier++){
  const sword=createSword(tier),bow=createBow(tier);
  for(const root of [sword,bow])root.traverse(o=>{const p=o.geometry?.attributes.position;if(p)for(const v of p.array)assert.ok(Number.isFinite(v));});
  for(const charge of [0,.5,1])for(const age of [Infinity,0,.04,.2]){
   const rig=bowRig(charge,age,1);applyBowRig(bow,rig);
   assert.equal(bow.getObjectByName('upper-limb').rotation.x,rig.bend);
   assert.equal(bow.getObjectByName('loaded-arrow').visible,rig.arrowVisible);
   const p=bow.getObjectByName('bowstring').geometry.attributes.position;
   assert.ok(Math.abs(p.getZ(1)-rig.nock[2])<1e-6);
  }
  assert.ok(sword.children.length<=2);assert.equal(bow.getObjectByName('upper-limb').children.length,1);
 }
});
