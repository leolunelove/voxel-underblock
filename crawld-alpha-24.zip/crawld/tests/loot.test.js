import test from 'node:test';import assert from 'node:assert/strict';
import {rollWeaponLoot,relicPower} from '../src/game/loot.js';
import {freshProfile,newRun,extract,forfeit,loadProfile} from '../src/game/expedition-rules.js';
import * as T from '../vendor/three.module.js';
import {Dungeon} from '../src/game/dungeon.js';
test('rare weapon sources roll once; finds strengthen the run and are banked only on extraction',()=>{
 const p=freshProfile(),a={...p,hp:100,loot:0},r=newRun();
 assert.equal(rollWeaponLoot(r,a,'miss',.2,.8,0),null);assert.equal(rollWeaponLoot(r,a,'miss',1,0,0),null);
 const drop=rollWeaponLoot(r,a,'chest',.4,0,0);assert.equal(drop.name,'Ashbound blade');assert.equal(relicPower(a,'sword'),1.15);assert.equal(p.relicSword,false);
 assert.equal(rollWeaponLoot(r,a,'chest',1,0,0),null);const duplicate=rollWeaponLoot(r,a,'other',1,0,0);assert.equal(duplicate.duplicate,true);assert.equal(a.loot,80);
 r.floor=3;assert.equal(extract(r,a,p,false,true),null);assert.equal(p.relicSword,false);extract(r,a,p,true,true);assert.equal(loadProfile(p).relicSword,true);assert.equal(rollWeaponLoot(r,a,'late',1,0,0),null);
 const failed=newRun(),b={...freshProfile(),hp:100,loot:0};rollWeaponLoot(failed,b,'bow',1,0,.9);assert.equal(b.relicBow,true);forfeit(failed,b);assert.equal(b.relicBow,false);assert.equal(p.relicBow,false);assert.equal(loadProfile({relicSword:'true'}).relicSword,false);
});
test('chest bands remain parented after world batching; lids open around their back hinge',()=>{
 const d=new Dungeon(new T.Scene(),{...freshProfile(),hp:100,loot:0},871,0,1),t=d.treasures.find(t=>t.kind==='treasure');
 assert.ok(t.lid.children.length>0);assert.ok(t.mesh.userData.lootGlow.parent===t.mesh);const z=t.lid.position.z;
 d.claimTreasure(t);for(let i=0;i<30;i++)d.update(t.mesh.position,.02);assert.ok(t.lid.rotation.x<-1.5);assert.equal(t.lid.position.z,z);assert.equal(d.treasureAvailable(new T.Vector3(t.mesh.position.x,2.65,t.mesh.position.z)),undefined);d.dispose();
});
