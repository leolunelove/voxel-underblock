import {stoneTexture} from './dungeon-look.js?v=25';
import * as T from '../../vendor/three.module.js?v=25';
// A playable threshold: shallow physical treads, a safe landing and no combat.
export function descentHeight(z){return 1-Math.min(16,Math.max(0,Math.floor((-z-2)/.8)))*.18;}
export class Descent{
 constructor(scene,floor=1){this.isDescent=true;this.root=new T.Group();scene.add(this.root);this.blockers=[];this.visited=new Set();this.rooms=[{style:floor===1?'The old stair':'The buried stair'}];this.combat={targets:[],enemies:[],update:()=>({}),cues:[]};this.time=0;this.lights=[];
 this.texture=stoneTexture(7821);const stone=new T.MeshStandardMaterial({color:0x777b63,map:this.texture,roughness:1}),dark=new T.MeshStandardMaterial({color:0x465240,map:this.texture,roughness:1}),iron=new T.MeshStandardMaterial({color:0x282c25,roughness:.9});
 const box=(w,h,d,x,y,z,mat=stone)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);this.root.add(m);return m;};
 for(let i=0;i<28;i++){const z=1.6-i*.8,h=descentHeight(z);box(4.4,.4,.8,0,h-.2,z);for(const side of [-1,1]){box(.6,4,.8,side*2.35,h+2,z,i%3?stone:dark);if(i%4===0){box(.24,3.5,.4,side*2.02,h+1.75,z,dark);box(4.3,.35,.4,0,h+3.65,z,dark);}if(i%7===0){box(.12,.5,.18,side*1.94,h+2.1,z,iron);const flame=box(.12,.25,.12,side*1.87,h+2.4,z,new T.MeshBasicMaterial({color:0xffcb7a}));const light=new T.PointLight(0xffb264,12,9,2);light.position.set(side*1.7,h+2.5,z);this.root.add(light);this.lights.push({light,flame});}if(i%5===1){const chip=box(.35,.18,.3,side*1.72,h+.09,z,dark);chip.rotation.y=i;}}
 box(4.5,.45,.8,0,h+4,z,dark);}
 // A dark arch frames the far landing, keeping the destination legible.
 box(.6,3.6,.5,-1.75,-.1,-18.8,dark);box(.6,3.6,.5,1.75,-.1,-18.8,dark);box(4.1,.6,.5,0,1.8,-18.8,dark);
 }
 roomAt(){return 0;}
 solid(x,y,z){return Math.abs(x)>2.05||z>2||z< -20||y<descentHeight(z)||y>descentHeight(z)+4;}
 blocked(){return false;}secretAvailable(){return null;}treasureAvailable(){return null;}cacheAvailable(){return false;}
 update(p,dt=0,reduced=false){this.time+=dt;this.complete=p.z< -18.5;for(const [i,f]of this.lights.entries())f.light.intensity=12*(reduced?1:1+Math.sin(this.time*8+i)*.04);}
 dispose(){this.root.removeFromParent();const gs=new Set(),ms=new Set();this.root.traverse(o=>{if(o.geometry)gs.add(o.geometry);if(o.material)ms.add(o.material);});gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());this.texture.dispose();}
}
