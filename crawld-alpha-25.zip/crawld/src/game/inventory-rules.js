import {SWORDS,BOWS} from './weapons.js?v=25';
import {swordDamage} from './hunt-rules.js?v=25';
import {RELICS,relicPower} from './loot.js?v=25';
export const relicEquippedField=kind=>kind==='sword'?'equipRelicSword':'equipRelicBow';
export function inventoryItems(profile,actor,run=null){const items=[];for(const kind of ['sword','bow']){const list=kind==='sword'?SWORDS:BOWS,top=profile[kind];for(let tier=0;tier<=top;tier++)items.push({id:kind+':'+tier,kind,tier,name:list[tier].name,rare:false,secured:true});if(actor[RELICS[kind].field])items.push({id:kind+':rare',kind,tier:top,name:RELICS[kind].name,rare:true,secured:!!profile[RELICS[kind].field]});}return items;}
export function itemEquipped(item,actor){return actor[item.kind]===item.tier&&item.rare===!!(actor[RELICS[item.kind].field]&&actor[relicEquippedField(item.kind)]!==false);}
export function itemStats(item,actor,run=null){const spec=(item.kind==='sword'?SWORDS:BOWS)[item.tier],damage=item.kind==='sword'?swordDamage(actor.xp,item.tier):spec.damage;return {damage:Math.round(damage*(item.rare?1.15:1)*(run?.edge??1)),speed:item.kind==='sword'?.5:spec.draw,range:item.kind==='sword'?3.05:spec.speed*2};}
export function equipInventoryItem(profile,actor,id,run=null){if(run?.ended||run&&actor.hp<=0)return false;const item=inventoryItems(profile,actor,run).find(i=>i.id===id);if(!item)return false;actor[item.kind]=item.tier;actor[relicEquippedField(item.kind)]=item.rare;if(!run){profile[item.kind==='sword'?'equippedSword':'equippedBow']=item.tier;profile[relicEquippedField(item.kind)]=item.rare;}return item;}
export function equippedName(kind,actor){return relicPower(actor,kind)>1?RELICS[kind].name:(kind==='sword'?SWORDS:BOWS)[actor[kind]].name;}
