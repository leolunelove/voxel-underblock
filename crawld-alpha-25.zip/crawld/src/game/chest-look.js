import * as T from '../../vendor/three.module.js?v=25';
export function dressChest(body,lid,secret=false){
 const iron=new T.MeshStandardMaterial({color:0x3f4942,roughness:.86,metalness:.25}),brass=new T.MeshStandardMaterial({color:secret?0x9b819b:0x9a8154,roughness:.8,metalness:.25}),wood=new T.MeshStandardMaterial({color:0x453629,roughness:1});
 const add=(parent,size,pos,mat)=>{const m=new T.Mesh(new T.BoxGeometry(...size),mat);m.position.set(...pos);m.userData.lootPart=true;parent.add(m);return m;};
 body.material.color.setHex(secret?0x3d3543:0x42392d);lid.material.color.setHex(0x504737);
 const w=body.geometry.parameters.width,d=body.geometry.parameters.depth,h=body.geometry.parameters.height;
 for(const x of [-w*.33,w*.33]){add(body,[.075,h+.03,d+.035],[x,0,0],iron);add(lid,[.075,.17,d+.045],[x,0,0],iron);for(const y of [-h*.28,h*.28])add(body,[.025,.025,.025],[x,y,d*.5+.027],brass);}
 for(const y of [-h*.36,0,h*.36])add(body,[w*.91,.025,.012],[0,y,d*.5+.009],wood);
 add(body,[.14,.22,.075],[0,h*.29,d*.5+.045],iron);add(body,[.045,.075,.085],[0,h*.29,d*.5+.05],brass);
 for(const x of [-w*.4,w*.4])add(body,[.12,.12,.13],[x,-h*.48,0],iron);
 // Back hinge: all lid details move with the lid, rather than floating separately.
 lid.geometry.translate(0,0,d*.5);for(const child of lid.children)child.position.z+=d*.5;lid.position.z-=d*.5;
 lid.userData.open=0;const glow=add(body,[w*.8,.025,d*.8],[0,h*.5+.02,0],new T.MeshBasicMaterial({color:secret?0xbca2df:0xd2ad60,transparent:true,opacity:0}));body.userData.lootGlow=glow;const coins=new T.Group();body.add(coins);coins.visible=false;for(let i=0;i<7;i++)add(coins,[.09,.035,.09],[((i*3)%7-3)*w*.085,h*.5+.04,(i%3-1)*d*.18],brass);body.userData.lootCoins=coins;
}
export function animateChest(body,lid,opened,dt,reduced){if(!lid.userData.hasOwnProperty('open'))return;const target=opened?-1.65:0;lid.rotation.x=reduced?target:lid.rotation.x+(target-lid.rotation.x)*(1-Math.exp(-dt*8));const glow=body.userData.lootGlow;if(glow)glow.material.opacity=opened?.22:0;if(body.userData.lootCoins)body.userData.lootCoins.visible=opened;}
