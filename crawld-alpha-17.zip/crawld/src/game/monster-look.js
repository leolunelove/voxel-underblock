import * as T from '../../vendor/three.module.js?v=17';
import {armorSurface,batchArmour} from './armor-look.js?v=17';
const ease=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);};
export function dressMonster(root,body,head,arms,type){
 const surface=armorSurface(type+19),armor=new T.MeshStandardMaterial({color:type===1?0x77857e:0x344b39,map:surface,roughness:.83,metalness:type===1?.30:.04}),rim=new T.MeshStandardMaterial({color:0x8b8e7a,map:surface,roughness:.8,metalness:.30}),ember=new T.MeshBasicMaterial({color:0xd6a56b}),bone=new T.MeshLambertMaterial({color:0xd7c79f}),dark=new T.MeshLambertMaterial({color:0x202b28}),leather=new T.MeshLambertMaterial({color:0x664b34});
 const box=(parent,s,p,mat)=>{const o=new T.Mesh(new T.BoxGeometry(...s),mat);o.position.set(...p);o.userData.armourDetail=true;parent.add(o);return o;};
 let jaw=null,shield=null;
 if(type===0){
 body.scale.set(1.08,.83,1.12);head.scale.set(1.16,.85,1.12);head.position.z=.18;
 box(body,[.96,.55,.35],[0,.15,-.35],armor);
 for(const x of [-.3,0,.3])box(body,[.12,.30,.15],[x,.49,-.29],bone);
 box(head,[.78,.12,.66],[0,.03,.02],armor);
 jaw=new T.Group();jaw.position.set(0,-.16,.07);head.add(jaw);box(jaw,[.72,.15,.62],[0,0,0],dark);
 for(const x of [-.25,.25]){box(jaw,[.10,.22,.11],[x,.06,.29],bone);box(head,[.09,.11,.1],[x,-.08,.31],bone);}
 for(const arm of arms){box(arm,[.28,.22,.30],[0,-.43,.02],armor);for(const x of [-.085,0,.085])box(arm,[.045,.27,.12],[x,-.72,.10],bone);}
 }else{
 // Sealed visor and layered bevor remove the friendly exposed face.
 box(head,[.82,.68,.78],[0,.04,.02],armor);box(head,[.64,.13,.64],[0,.43,-.02],armor);
 box(head,[.91,.12,.84],[0,.23,.07],rim);box(head,[.75,.12,.06],[0,.11,.45],dark);
 for(const x of [-.19,.19])box(head,[.16,.035,.035],[x,.11,.49],ember);
 box(head,[.14,.56,.08],[0,-.02,.48],armor);
 for(const x of [-.28,-.14,.14,.28]){box(head,[.065,.24,.08],[x,-.18,.46],rim);box(head,[.035,.035,.03],[x,.27,.51],bone);}
 box(head,[.82,.12,.76],[0,-.34,.04],armor);
 box(body,[1.01,.72,.78],[0,.01,.03],armor);box(body,[.78,.18,.16],[0,.21,.46],rim);
 for(const y of [-.22,-.04,.12]){box(body,[.90,.10,.14],[0,y,.45],armor);for(const x of [-.35,.35])box(body,[.045,.045,.04],[x,y,.54],rim);}
 box(body,[.97,.14,.83],[0,-.38,0],leather);box(body,[.18,.17,.07],[0,-.38,.47],rim);
 for(const side of [-1,1]){
 const arm=arms[side===-1?0:1];box(arm,[.58,.32,.82],[side*.03,.02,0],armor);box(arm,[.62,.08,.88],[side*.03,.20,0],rim);
 box(arm,[.19,.27,.24],[side*.18,.36,-.04],armor);box(arm,[.10,.17,.15],[side*.19,.56,-.05],rim);
 box(arm,[.36,.35,.38],[0,-.44,0],armor);for(const y of [-.35,-.50])box(arm,[.38,.05,.40],[0,y,0],rim);
 box(root,[.36,.38,.40],[side*.25,.26,.02],armor);box(root,[.38,.10,.46],[side*.25,.08,.09],rim);
 // Short split tabard, kept inside the existing body envelope.
 box(body,[.29,.36,.08],[side*.19,-.54,.36],dark);
 }
 shield=new T.Group();arms[0].add(shield);shield.position.set(0,-.47,.17);
 box(shield,[.76,.94,.18],[0,0,.07],dark);
 for(const x of [-.23,0,.23])box(shield,[.21,.82,.12],[x,0,.20],armor);
 for(const y of [-.35,.35])box(shield,[.77,.09,.21],[0,y,.17],rim);
 for(const x of [-.29,.29])for(const y of [-.27,.27])box(shield,[.055,.055,.07],[x,y,.30],bone);
 box(shield,[.22,.26,.16],[0,0,.31],armor);box(shield,[.07,.34,.03],[0,0,.41],rim);
 box(arms[1],[.11,.79,.11],[0,-.66,.02],leather);box(arms[1],[.40,.43,.17],[.10,-.96,.03],armor);box(arms[1],[.07,.45,.19],[.32,-.96,.03],rim);box(arms[1],[.13,.12,.21],[-.12,-.85,.03],rim);
 }
 batchArmour(root);
 const bar=new T.Group();bar.position.set(0,2.18,0);box(bar,[.90,.085,.025],[0,0,0],dark);
 const lag=box(bar,[.82,.048,.03],[0,0,.018],new T.MeshBasicMaterial({color:0xb65e42})),fill=box(bar,[.82,.048,.03],[0,0,.025],new T.MeshBasicMaterial({color:0xe8bc71}));
 bar.traverse(o=>o.userData.effect=true);root.add(bar);bar.visible=false;
 return {head,armor,bar,fill,lag,jaw,shield,time:0,displayHP:1};
}
export function animateMonster(e,dt,reduced,distance){
 const v=e.look;if(!v)return;v.time+=dt;
 const brain=e.brain,a=brain.attack,wind=brain.state==='windup',active=brain.state==='active',recover=brain.state==='recovery',crawl=e.type===0;
 const hit=Math.max(0,Math.min(1,e.hit/.27)),recoil=hit*hit*(e.impactStrength??1),side=e.slashSide??1,charge=ease(brain.progress),cut=active?ease(1-brain.remaining/a.active):0;
 const moving=brain.state==='idle'&&distance>(crawl?2.7:1.95)&&distance<14&&e.stagger<=0;
 v.hitTime=e.hit>0?2:Math.max(0,(v.hitTime??0)-dt);v.bar.visible=e.hp<e.maxHp&&v.hitTime>0;
 const hp=e.hp/e.maxHp;v.displayHP=Math.max(hp,v.displayHP-dt*.75);v.fill.scale.x=Math.max(.001,hp);v.fill.position.x=-(1-hp)*.41;v.lag.scale.x=Math.max(.001,v.displayHP);v.lag.position.x=-(1-v.displayHP)*.41;
 v.armor.emissive.setHex(e.hit>0?0x95613f:wind?0x633b14:0);v.armor.emissiveIntensity=e.hit>0?hit*.9:wind?charge*.24:0;
 if(reduced){v.head.rotation.set(0,0,0);e.body.rotation.set(0,0,0);e.root.position.y=1;e.arms.forEach(x=>x.rotation.set(0,0,0));e.legs.forEach(x=>x.rotation.set(0,0,0));if(v.jaw)v.jaw.rotation.x=0;return;}
 const stride=Math.sin(e.timer),settle=recover?Math.min(1,brain.remaining/.35):0;
 e.root.position.y=1+(moving?Math.abs(stride)*(crawl?.065:.035):Math.sin(v.time*2.4)*.012)-(wind&&crawl?charge*.24:0)+(active&&crawl?Math.sin(cut*Math.PI)*.32:0);
 e.body.rotation.set((crawl?.16:0)+(wind?charge*(crawl?.20:-.12):active?.20*cut:recover?.12*settle:0),wind&&!crawl?-charge*.18:0,recoil*(crawl?.38:.18)*side+(moving?stride*.035:0));
 v.head.rotation.set(-recoil*.38+(wind?-charge*.24:active?.16:0),moving?Math.sin(e.timer*.5)*.045:0,-recoil*.28*side);
 if(v.jaw)v.jaw.rotation.x=wind?-charge*.48:active?-.5*(1-cut):-.06;
 e.arms.forEach((arm,i)=>{
 const sign=i===0?-1:1;let x=moving?Math.sin(e.timer+i*Math.PI)*(crawl?.65:.23):crawl?-.25:.12,z=crawl?sign*.13:sign*.04,y=0;
 if(wind){if(crawl){x=-.4-charge*1.5;z=sign*(.15+charge*.65);}else if(a.id==='bash'){x=i===0?-.8-charge*.25:-.25;z=i===0?-.24:charge*.20;}else{x=i===1?-charge*2.65:-.55;z=sign*charge*.14;y=i===1?-charge*.25:0;}}
 else if(active){if(crawl){x=-1.9+cut*2.9;z=sign*(.8-cut*.7);}else if(a.id==='bash'){x=i===0?-1.6+cut*.5:.4;z=i===0?.15:0;}else{x=i===1?-2.65+cut*3.6:-.45;z=i===1?cut*.22:0;}}
 else if(recover){x=crawl?.45*settle:i===1?.85*settle:-.25;}
 x+=recoil*.65;z+=sign*recoil*.28;arm.rotation.set(x,y,z);
 });
 e.legs.forEach((leg,i)=>{leg.rotation.x=moving?Math.sin(e.timer+i*Math.PI)*(crawl?.52:.32):wind&&crawl?-.3*charge:0;leg.rotation.z=crawl?(i===0?-.10:.10):0;});
}
