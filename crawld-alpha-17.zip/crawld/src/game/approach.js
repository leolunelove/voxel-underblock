import * as T from '../../vendor/three.module.js?v=17';
// A short, safe threshold. Its single trail leads directly into floor one.
export class Approach{
 constructor(scene){this.scene=scene;this.isApproach=true;this.root=new T.Group();scene.add(this.root);this.rooms=[{x:0,z:0,style:'Ashen foothills'}];this.visited=new Set([0]);this.blockers=[];this.treasures=[];this.secrets=[];this.cleared=false;this.atExit=false;this.combat={enemies:[],targets:[],cues:[],update:()=>({defeated:false})};const groups=new Map(),pixels=new Uint8Array(64*64*4);let noise=983;for(let y=0;y<64;y++)for(let x=0;x<64;x++){noise=(Math.imul(noise,1664525)+1013904223)>>>0;const v=112+(noise%24)+(y%11===0?-23:0),i=(y*64+x)*4;pixels[i]=v*.91;pixels[i+1]=v;pixels[i+2]=v*.83;pixels[i+3]=255;}this.rockTexture=new T.DataTexture(pixels,64,64);this.rockTexture.colorSpace=T.SRGBColorSpace;this.rockTexture.magFilter=this.rockTexture.minFilter=T.NearestFilter;this.rockTexture.needsUpdate=true;
 const box=(w,h,d,x,y,z,color)=>{if(!groups.has(color))groups.set(color,[]);groups.get(color).push([w,h,d,x,y,z]);};
 box(110,1,110,0,.5,-5,0x343b30);
 // The path is hemmed in by rocks rather than optional forks.
 for(let z=-12;z<=13;z++)for(const side of [-1,1]){const n=(z*17+91)%7;box(2.2,1.1+Math.abs(n)*.14,1.3,side*(5.1+Math.sin(z)*.3),1.5,z,0x404a40);}
 for(let z=-11;z<=12;z++)for(let x=-3;x<=3;x++){if((x*13+z*7)%4===0)box(.8,.025,.7,x+.15,1.02,z,0x66604b);}
 // Overlapping strata form a mountain face with a dark, stepped cave mouth.
 for(const side of [-1,1])for(let i=0;i<7;i++){const x=side*(5+i*3.4),h=14-i*1.25+(i%2)*1.5;box(4.5,h,8+i, x,1+h/2,-16-i*.6,i%2?0x5c675b:0x687263);box(4,2,5,x+.5,h+1,-18-i,0x707b68);}
 for(const [w,y] of [[12,7.5],[15,10],[18,13],[22,16],[20,19],[14,22]])box(w,3,9,0,y,-17,0x66705e);
 for(const side of [-1,1]){box(2.1,5,4,side*3.6,3.5,-13,0x50584e);box(1.5,1.2,4,side*2.7,5.6,-13,0x5a6154);box(.85,.8,4,side*1.8,6.3,-13,0x535b50);box(.8,4.5,5,side*2.9,3.2,-15,0x303a32);}
 box(5.7,4.8,.3,0,3.35,-17.5,0x080e0b);
 for(const side of [-1,1])for(let i=0;i<6;i++){const x=side*(9+(i%3)*4),z=7-i*5;box(.4,4,.4,x,3,z,0x38372a);for(let j=0;j<4;j++)box(3.2-j*.55,.9,3.2-j*.55,x,3+j*.8,z,0x243c32);}
 for(const side of [-1,1]){const x=side*2.4;box(.22,1.4,.22,x,1.7,-10.7,0x322d24);box(.5,.18,.5,x,2.4,-10.7,0x292f28);const fire=new T.Mesh(new T.BoxGeometry(.22,.35,.22),new T.MeshBasicMaterial({color:0xe7bd72}));fire.position.set(x,2.65,-10.7);this.root.add(fire);const light=new T.PointLight(0xffb56a,7,10,2);light.position.set(x,3,-10);this.root.add(light);}
 const geo=new T.BoxGeometry(1,1,1),matrix=new T.Matrix4();for(const [color,list]of groups){const m=new T.InstancedMesh(geo,new T.MeshStandardMaterial({color:[0x5c675b,0x687263,0x66705e,0x707b68,0x50584e,0x5a6154,0x535b50].includes(color)?0xb8c0a6:color,map:[0x5c675b,0x687263,0x66705e,0x707b68,0x50584e,0x5a6154,0x535b50].includes(color)?this.rockTexture:null,roughness:1}),list.length);list.forEach(([w,h,d,x,y,z],i)=>{matrix.makeScale(w,h,d);matrix.setPosition(x,y,z);m.setMatrixAt(i,matrix);});this.root.add(m);}
 for(const [x,h,z]of [[-26,34,-40],[20,41,-46],[0,48,-56]]){const mountain=new T.Mesh(new T.ConeGeometry(20,h,5),new T.MeshStandardMaterial({color:0x657464,roughness:1,flatShading:true}));mountain.position.set(x,h/2,z);mountain.rotation.y=.3;this.root.add(mountain);}
 const sky=new T.HemisphereLight(0xc4d0c2,0x536044,1.8);this.root.add(sky);const moon=new T.DirectionalLight(0xc9d2ba,2.1);moon.position.set(-15,25,8);this.root.add(moon);
 }
 entranceAvailable(p){return p.z< -9&&Math.abs(p.x)<2.7;}
 roomAt(){return 0;}solid(x,y,z){return y<1||Math.abs(x)>4.15||z>13||z< -13.5;}
 blocked(ray,distance){for(let d=.1;d<distance;d+=.12){const p=ray.at(d,new T.Vector3());if(this.solid(p.x,p.y,p.z))return true;}return false;}
 update(){}secretAvailable(){return null;}treasureAvailable(){return null;}cacheAvailable(){return false;}dispose(){this.root.removeFromParent();const gs=new Set(),ms=new Set();this.root.traverse(o=>{if(o.geometry)gs.add(o.geometry);if(o.material)ms.add(o.material);if(o.isInstancedMesh)o.dispose();});this.rockTexture.dispose();gs.forEach(g=>g.dispose());ms.forEach(m=>m.dispose());}
}
